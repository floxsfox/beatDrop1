extends Control
## Panel dengan latar shader (gradien, border, glow, bayangan) yang meniru gaya CSS asli.
## Mouse filter = PASS supaya sentuhan tetap sampai ke area scroll / carousel di belakangnya.

const FX = preload("res://scripts/fx.gd")

var body: MarginContainer = null
var _bg: ColorRect
var _mat: ShaderMaterial
var _pad := 0.0
var _shine := false
var _clock := 0.0


func _init() -> void:
	# Aman dipanggil lebih dari sekali (turunan harus memanggil super() secara eksplisit di Godot 4).
	if _bg != null:
		return
	mouse_filter = Control.MOUSE_FILTER_PASS
	_bg = ColorRect.new()
	_bg.color = Color.WHITE
	_bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mat = ShaderMaterial.new()
	_mat.shader = FX.panel_shader()
	_bg.material = _mat
	add_child(_bg)
	resized.connect(_sync)
	set_process(false)


func _sync() -> void:
	_bg.anchor_left = 0.0
	_bg.anchor_top = 0.0
	_bg.anchor_right = 1.0
	_bg.anchor_bottom = 1.0
	_bg.offset_left = -_pad
	_bg.offset_top = -_pad
	_bg.offset_right = _pad
	_bg.offset_bottom = _pad
	_mat.set_shader_parameter("psize", size + Vector2(_pad * 2.0, _pad * 2.0))
	_mat.set_shader_parameter("pad", _pad)
	pivot_offset = size / 2.0


## Terapkan gaya (kunci: c1,c2,cm,mid,ang,bcol,bw,rad,gcol,gsz,hi,lip,scol,soff,sblur,shine).
func style(d: Dictionary) -> void:
	var gsz: float = d.get("gsz", 0.0)
	var soff: Vector2 = d.get("soff", Vector2.ZERO)
	var sblur: float = d.get("sblur", 1.0)
	var sext := 0.0
	if d.has("scol"):
		sext = maxf(absf(soff.x), absf(soff.y)) + sblur
	_pad = ceilf(maxf(gsz, sext))
	_mat.set_shader_parameter("c1", d.get("c1", Color(0.2, 0.15, 0.4, 1.0)))
	_mat.set_shader_parameter("c2", d.get("c2", d.get("c1", Color(0.1, 0.08, 0.2, 1.0))))
	_mat.set_shader_parameter("cm", d.get("cm", Color(0, 0, 0, 0)))
	_mat.set_shader_parameter("mid", d.get("mid", 0.55))
	_mat.set_shader_parameter("ang", deg_to_rad(float(d.get("ang", 135.0)) - 90.0))
	_mat.set_shader_parameter("bcol", d.get("bcol", Color(1, 1, 1, 0.0)))
	_mat.set_shader_parameter("bw", d.get("bw", 1.0))
	_mat.set_shader_parameter("rad", d.get("rad", 16.0))
	_mat.set_shader_parameter("gcol", d.get("gcol", Color(0, 0, 0, 0)))
	_mat.set_shader_parameter("gsz", gsz)
	_mat.set_shader_parameter("hi", d.get("hi", 0.0))
	_mat.set_shader_parameter("lip", d.get("lip", 0.0))
	_mat.set_shader_parameter("scol", d.get("scol", Color(0, 0, 0, 0)))
	_mat.set_shader_parameter("soff", soff)
	_mat.set_shader_parameter("sblur", sblur)
	_shine = bool(d.get("shine", false))
	if not _shine:
		_mat.set_shader_parameter("shine", -5.0)
	set_process(_shine)
	_sync()


func _process(delta: float) -> void:
	if not _shine or not is_visible_in_tree():
		return
	_clock += delta
	var ph := fposmod(_clock / 3.2, 1.0)
	var p := clampf((ph - 0.55) / 0.45, 0.0, 1.0)
	_mat.set_shader_parameter("shine", lerpf(-0.5, 1.4, p) if p > 0.0 else -5.0)


## Wadah isi dengan padding (anchor penuh). Ukuran minimum panel mengikuti isi.
func make_body(l: float = 0.0, t: float = 0.0, r: float = 0.0, b: float = 0.0) -> MarginContainer:
	body = MarginContainer.new()
	body.mouse_filter = Control.MOUSE_FILTER_PASS
	body.set_anchors_preset(Control.PRESET_FULL_RECT)
	body.add_theme_constant_override("margin_left", int(l))
	body.add_theme_constant_override("margin_top", int(t))
	body.add_theme_constant_override("margin_right", int(r))
	body.add_theme_constant_override("margin_bottom", int(b))
	add_child(body)
	body.minimum_size_changed.connect(update_minimum_size)
	return body


func _get_minimum_size() -> Vector2:
	if body != null:
		return body.get_combined_minimum_size()
	return Vector2.ZERO
