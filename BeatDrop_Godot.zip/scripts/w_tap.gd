extends Control
## Area ketuk yang tetap membiarkan ScrollContainer menggulir (kartu lagu, dsb).

signal tapped

var _down := false
var _p0 := Vector2.ZERO
var _t0 := 0


func _init() -> void:
	mouse_filter = Control.MOUSE_FILTER_PASS


func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		if e.pressed:
			_down = true
			_p0 = e.global_position
			_t0 = Time.get_ticks_msec()
		elif _down:
			_down = false
			if e.global_position.distance_to(_p0) < 14.0 and Time.get_ticks_msec() - _t0 < 500:
				tapped.emit()
