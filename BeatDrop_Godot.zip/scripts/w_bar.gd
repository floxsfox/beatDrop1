extends Control
## Bar progres gradien (pink -> hijau) untuk layar loading.

var value := 0.0:
	set(v):
		value = clampf(v, 0.0, 1.0)
		queue_redraw()


func _init() -> void:
	custom_minimum_size = Vector2(300, 10)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _draw() -> void:
	var h := size.y
	var r := h / 2.0
	draw_line(Vector2(r, r), Vector2(size.x - r, r), Color(1, 1, 1, 0.1), h)
	draw_circle(Vector2(r, r), r, Color(1, 1, 1, 0.1))
	draw_circle(Vector2(size.x - r, r), r, Color(1, 1, 1, 0.1))
	if value <= 0.0:
		return
	var x1 := maxf(h, size.x * value)
	var a := Color("#ff3d81")
	var b := Color("#2ee6a6")
	draw_circle(Vector2(r, r), r, a)
	var n := 24
	for i in n:
		var u0 := float(i) / float(n)
		var u1 := float(i + 1) / float(n)
		draw_line(Vector2(r + (x1 - h) * u0, r), Vector2(r + (x1 - h) * u1 + 1.0, r), a.lerp(b, (u0 + u1) * 0.5), h)
	draw_circle(Vector2(x1 - r, r), r, a.lerp(b, 1.0))
