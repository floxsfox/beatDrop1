extends Node2D
## Satu skrip untuk semua layer gambar game (mode menentukan isi).
## 0 = latar gradien, 4 = cahaya (alpha mengikuti bass), 1 = lajur statis (digambar ulang hanya saat layout berubah),
## 2 = not/partikel (tiap frame), 3 = fluida aditif (tiap frame).
## Seluruh bentuk diproyeksikan ke kamera miring lewat g.P(), tanpa offscreen buffer.

var g: Node = null
var mode := 0

var _q_pts := PackedVector2Array([Vector2.ZERO, Vector2.ZERO, Vector2.ZERO, Vector2.ZERO])
var _q_cols := PackedColorArray([Color.WHITE, Color.WHITE, Color.WHITE, Color.WHITE])
var _q_uvs := PackedVector2Array([Vector2(0, 0), Vector2(1, 0), Vector2(1, 1), Vector2(0, 1)])


func _ready() -> void:
	set_process(mode == 4)
	if mode == 3:
		var m := CanvasItemMaterial.new()
		m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		material = m


func _process(_delta: float) -> void:
	if g == null:
		return
	modulate.a = clampf(0.32 + float(g.pul) * 0.7, 0.0, 1.0) if Store.SET["glow"] else 0.12


func _draw() -> void:
	if g == null:
		return
	match mode:
		0:
			_draw_bg()
		1:
			_draw_lanes()
		2:
			_draw_dyn()
		3:
			_draw_fluid()
		4:
			_draw_glow()


func _quad(x0: float, y0: float, x1: float, y1: float, ct: Color, cb: Color, tex: Texture2D = null) -> void:
	_q_pts[0] = g.P(x0, y0)
	_q_pts[1] = g.P(x1, y0)
	_q_pts[2] = g.P(x1, y1)
	_q_pts[3] = g.P(x0, y1)
	_q_cols[0] = ct
	_q_cols[1] = ct
	_q_cols[2] = cb
	_q_cols[3] = cb
	draw_primitive(_q_pts, _q_cols, _q_uvs, tex)


func _rr_pts(x: float, y: float, w: float, h: float, r: float, closed: bool = false) -> PackedVector2Array:
	var rr := maxf(0.6, minf(r, minf(w, h) / 2.0))
	var pts := PackedVector2Array()
	var cx := [x + w - rr, x + w - rr, x + rr, x + rr]
	var cy := [y + rr, y + h - rr, y + h - rr, y + rr]
	var a0 := [-PI / 2.0, 0.0, PI / 2.0, PI]
	for ci in 4:
		for s in 7:
			var a: float = a0[ci] + (PI / 2.0) * float(s) / 6.0
			pts.append(g.P(float(cx[ci]) + cos(a) * rr, float(cy[ci]) + sin(a) * rr))
	if closed:
		pts.append(pts[0])
	return pts


func _circle_pts(cx: float, cy: float, r: float, closed: bool = false) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in 40:
		var a := TAU * float(i) / 40.0
		pts.append(g.P(cx + cos(a) * r, cy + sin(a) * r))
	if closed:
		pts.append(pts[0])
	return pts


func _draw_bg() -> void:
	var pts := PackedVector2Array([Vector2(0, 0), Vector2(g.W, 0), Vector2(g.W, g.H), Vector2(0, g.H)])
	var top := Color("#0d0a26")
	var bot := Color("#1c0b30")
	draw_primitive(pts, PackedColorArray([top, top, bot, bot]), PackedVector2Array())


func _draw_glow() -> void:
	var r: float = g.H * 0.85
	draw_texture_rect(g.glow_tex, Rect2(g.W * 0.5 - r, g.HY - r, r * 2.0, r * 2.0), false)


func _draw_lanes() -> void:
	var cols: Array = Store.colors
	var ex0: float = roundf(g.LX)
	var ex1: float = roundf(g.LX + g.L)
	var pan := Color(0.027, 0.02, 0.07, 0.66)
	_quad(ex0, 0.0, ex1, g.H, pan, pan)
	var gl := Color(1, 1, 1, 0.08)
	for i in 6:
		var x: float = roundf(g.LX + float(i) * g.LW) + 0.5
		draw_line(g.P(x, g.H), g.P(x, 0.0), gl, 1.0)
	var hyr: float = roundf(g.HY)
	var hl := Color(1, 1, 1, 0.75)
	_quad(ex0, hyr - 1.0, ex1, hyr + 2.0, hl, hl)
	var hole := int(Store.SET["hole"])
	var ph: float = g.H - g.PY - g.sb_bot - 8.0
	for l in 5:
		var c: Color = cols[l]
		var la: float = roundf(g.LX + float(l) * g.LW)
		var lb: float = roundf(g.LX + float(l + 1) * g.LW)
		var hx: float = la + roundf(g.LW * 0.08)
		var hw: float = lb - la - roundf(g.LW * 0.16)
		var hh: float = g.HHt
		var hy: float = g.HY - hh / 2.0
		match hole:
			1:
				draw_polyline(_circle_pts(hx + hw / 2.0, hy + hh / 2.0, minf(hw, hh) / 2.0, true), c, 3.0, true)
			2:
				draw_polyline(_rr_pts(hx, hy, hw, hh, 0.6, true), c, 3.0, true)
			3:
				var s := minf(hw, hh)
				draw_polyline(_rr_pts(hx + (hw - s) / 2.0, hy + (hh - s) / 2.0, s, s, 0.6, true), c, 3.0, true)
			_:
				draw_polyline(_rr_pts(hx, hy, hw, hh, hh * 0.45, true), c, 3.0, true)
		if ph > 10.0:
			draw_colored_polygon(_rr_pts(la + 4.0, g.PY, lb - la - 8.0, ph, 14.0), Color(c.r, c.g, c.b, 0.08))
	var rc := Color(0.6, 0.47, 1.0, 0.85)
	draw_line(g.P(ex0, g.H), g.P(ex0, 0.0), rc, 2.5, true)
	draw_line(g.P(ex1, g.H), g.P(ex1, 0.0), rc, 2.5, true)


func _draw_dyn() -> void:
	if g.state == "idle":
		return
	var now: float = g.hold_now
	var cols: Array = Store.colors
	var glow_on: bool = Store.SET["glow"]
	var pad: Array = g.pad
	var LX: float = g.LX
	var LW: float = g.LW
	var HY: float = g.HY
	var H: float = g.H
	if glow_on:
		var ph: float = H - g.PY - g.sb_bot - 8.0
		for l in 5:
			var pv: float = pad[l]
			if pv > 0.01:
				var c: Color = cols[l]
				var x0 := LX + float(l) * LW
				_quad(x0, HY - H * 0.5, x0 + LW, HY, Color(c.r, c.g, c.b, 0.0), Color(c.r, c.g, c.b, pv * 0.4))
				if ph > 10.0:
					draw_colored_polygon(_rr_pts(roundf(x0) + 4.0, g.PY, LW - 8.0, ph, 14.0), Color(c.r, c.g, c.b, pv * 0.3))
	# not
	var nt: PackedFloat32Array = g.n_t
	var nd: PackedFloat32Array = g.n_d
	var nl: PackedInt32Array = g.n_l
	var nst: PackedInt32Array = g.n_st
	var nfl: PackedInt32Array = g.n_fl
	var tex: Texture2D = g.note_mask
	var nw: float = g.NW
	var nht: float = g.NHt
	var bw: float = g.SQ if int(Store.SET["nshape"]) == 1 else nw
	var v2: bool = g.v2_play
	var app: float = g.APP
	var sp: float = g.SP
	for i in range(g.ni, g.n_count):
		var dtn: float = nt[i] - now
		if dtn > app + 0.15:
			break
		var fl: int = nfl[i]
		if v2 and (fl & 4) == 0:
			break
		var st: int = nst[i]
		var dim := (fl & 3) != 0
		if st == 2 and not dim:
			continue
		var l: int = nl[i]
		var c: Color = cols[l]
		var x := roundf(LX + float(l) * LW + LW * 0.08)
		var holding := st == 1
		var y: float = HY if holding else HY - dtn * sp
		if nd[i] > 0.0:
			var ye := maxf(HY - (nt[i] + nd[i] - now) * sp, -20.0)
			if y > ye:
				var ha := 0.12 if dim else (0.75 if holding else 0.45)
				var hc := Color(c.r, c.g, c.b, ha)
				_quad(x + nw * 0.2, ye, x + nw * 0.8, y, hc, hc)
		if y < H + 20.0:
			var al := 0.28 if dim else 1.0
			var bx := x + (nw - bw) / 2.0
			var y0 := y - nht / 2.0
			var gc := Color(c.r, c.g, c.b, 0.35 * al)
			_quad(bx - 4.0, y0 - 4.0, bx + bw + 4.0, y0 + nht + 4.0, gc, gc, tex)
			var top := c.lerp(Color.WHITE, 0.8)
			top.a = al
			var bot := Color(c.r, c.g, c.b, al)
			_quad(bx, y0, bx + bw, y0 + nht, top, bot, tex)
	# partikel percikan
	var pl: PackedFloat32Array = g.p_l
	var px: PackedFloat32Array = g.p_x
	var py: PackedFloat32Array = g.p_y
	var pc: PackedInt32Array = g.p_c
	for i in g.MAXP:
		var lf: float = pl[i]
		if lf <= 0.0:
			continue
		var c2: Color = cols[pc[i]]
		draw_circle(g.P(px[i], py[i]), (2.0 + lf * 3.0) * g.Pscale(py[i]), Color(c2.r, c2.g, c2.b, minf(1.0, lf)))


func _draw_fluid() -> void:
	if g.state == "idle":
		return
	var cols: Array = Store.colors
	var fl: PackedFloat32Array = g.f_l
	var fx: PackedFloat32Array = g.f_x
	var fy: PackedFloat32Array = g.f_y
	var fs: PackedFloat32Array = g.f_s
	var fc: PackedInt32Array = g.f_c
	var tex: Texture2D = g.fluid_tex
	for i in g.MAXF:
		var lf: float = fl[i]
		if lf <= 0.0:
			continue
		var p: Vector2 = g.P(fx[i], fy[i])
		var r: float = (8.0 + 24.0 * fs[i]) * sin(minf(1.0, (1.0 - lf) * 5.0) * 1.57) * sqrt(lf) * g.Pscale(fy[i]) * g.S
		if r < 0.5:
			continue
		var c: Color = cols[fc[i]]
		draw_texture_rect(tex, Rect2(p.x - r, p.y - r, r * 2.0, r * 2.0), false, Color(c.r, c.g, c.b, minf(1.0, lf * 1.5) * 0.9))
