extends "res://scripts/s_base.gd"
## Pustaka lagu ("Play"): carousel kartu sampul. Nilai terbaik tiap lagu tampil sebagai lencana.

const C = preload("res://scripts/consts.gd")
const WCarLib = preload("res://scripts/w_car_lib.gd")

var _car
var _empty: Label
var _sub: Label


func _ready() -> void:
	var col := UI.vbox(6)
	mc.add_child(col)
	var up := UI.btn("Upload", 12, FX.s_primary(), Vector2(84, 30), Color.WHITE, 1)
	up.style({"c1": FX.PINK, "c2": FX.VIOLET, "ang": 90.0, "bw": 0.0, "rad": 12.0, "hi": 0.2, "gcol": Color(1, 0.24, 0.5, 0.4), "gsz": 10.0, "shine": true})
	up.set_icon(UI.icon("plus"), 11, Color.WHITE, true)
	up.label.offset_left = 8.0
	up.pressed.connect(func(): nav.emit("pick", {}))
	var h := make_header("Song Library", "Swipe to browse · tap the center song", "menu", up)
	_sub = h.get_meta("sub")
	col.add_child(h)
	_car = WCarLib.new()
	_car.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_car.custom_minimum_size = Vector2(0, 150)
	col.add_child(_car)
	_empty = UI.label("No songs yet.\nTap Upload and choose an MP3 / OGG from your file manager.", 14, FX.MUT, "medium", HORIZONTAL_ALIGNMENT_CENTER)
	_empty.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_empty.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(_empty)
	_car.activated.connect(_on_activate)


func on_enter(_args: Dictionary = {}) -> void:
	refresh()
	fade_in(0.3)


func refresh() -> void:
	var items: Array = []
	var lib: Array = Store.library
	for i in range(lib.size() - 1, -1, -1):
		var e: Dictionary = lib[i]
		var id: String = e["id"]
		items.append({
			"id": id, "name": String(e["name"]),
			"meta": "%s · %.1f MB" % [C.fmt_dur(float(e["dur"])), float(e["bytes"]) / 1048576.0],
			"grade": Store.grade_best(id), "best": Store.best_any(id), "tex": Store.thumb_texture(id),
		})
	_car.setup(items)
	_car.jump_to(0)
	_car.visible = items.size() > 0
	_empty.visible = items.is_empty()
	var n := items.size()
	_sub.text = "Swipe to browse · tap the center song" if n > 0 else "Add your first song"


func _on_activate(i: int) -> void:
	var items: Array = _car.items
	if i >= 0 and i < items.size():
		nav.emit("open_song", {"id": String(items[i]["id"])})
