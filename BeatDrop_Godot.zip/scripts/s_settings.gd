extends "res://scripts/s_base.gd"
## Pengaturan bergaya versi web: rel tab di kiri (Colors, Shapes, Camera, Effects, Graphics) + panel isi.

signal changed

const C = preload("res://scripts/consts.gd")
const WWheel = preload("res://scripts/w_wheel.gd")
const TABS := [["Colors", "palette"], ["Shapes", "diamond"], ["Camera", "camera"], ["Effects", "sparkle"], ["Graphics", "monitor"]]
const RES_KEYS := [40, 50, 75, 100]
const TAB_ON := {"c1": Color(1.0, 0.24, 0.5, 0.55), "c2": Color(0.486, 0.36, 1.0, 0.55), "ang": 135.0, "bcol": Color("#ff3d81"), "bw": 1.5, "rad": 13.0,
		"gcol": Color(1.0, 0.24, 0.5, 0.35), "gsz": 8.0}

var _holder: Control
var _tabs: Array = []
var _pages: Array = []
var _wheel
var _lanes: Array = []
var _sel_lane := 0
var _sat_val: Label
var _sat_sl
var _tilt_val: Label
var _tilt_sl
var _tilt_prev: Control
var _cache_lbl: Label
var _v2_box: VBoxContainer
var _v3_box: VBoxContainer
var _eff_cards := {}
var _ver_lbl: Label


func _ready() -> void:
	var col := UI.vbox(6)
	mc.add_child(col)
	col.add_child(make_header("Settings", "", "menu"))
	var row := UI.hbox(10)
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(row)
	var rail := UI.vbox(5)
	rail.custom_minimum_size = Vector2(108, 0)
	row.add_child(rail)
	for i in TABS.size():
		var t := UI.btn("", 12, FX.s_row(false, FX.VIOLET), Vector2(108, 40))
		t.size_flags_vertical = Control.SIZE_EXPAND_FILL
		var b := t.make_body(10, 0, 6, 0)
		var h := UI.hbox(7)
		h.alignment = BoxContainer.ALIGNMENT_BEGIN
		var ic := UI.icon_rect(String(TABS[i][1]), 17, Color("#b9b3e8"))
		ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		var lb := UI.label(String(TABS[i][0]), 12, Color("#b9b3e8"), "bold")
		lb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		h.add_child(ic)
		h.add_child(lb)
		b.add_child(h)
		t.set_meta("ic", ic)
		t.set_meta("lb", lb)
		t.pressed.connect(func(): _show_tab(i))
		_tabs.append(t)
		rail.add_child(t)
	var panel := UI.card(FX.s_panel(), 10, 8, 6, 8)
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	row.add_child(panel)
	_holder = Control.new()
	_holder.mouse_filter = Control.MOUSE_FILTER_PASS
	_holder.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_holder.size_flags_vertical = Control.SIZE_EXPAND_FILL
	panel.body.add_child(_holder)
	_build_colors()
	_build_shapes()
	_build_camera()
	_build_effects()
	_build_graphics()
	_show_tab(0)


func _page() -> VBoxContainer:
	var sc := UI.WScroll.new()
	sc.set_anchors_preset(Control.PRESET_FULL_RECT)
	_holder.add_child(sc)
	sc.content.add_theme_constant_override("separation", 8)
	_pages.append(sc)
	return sc.content


func _show_tab(i: int) -> void:
	for k in _pages.size():
		_pages[k].visible = k == i
		var t = _tabs[k]
		var on := k == i
		t.style(TAB_ON if on else FX.s_row(false, FX.VIOLET))
		(t.get_meta("ic") as TextureRect).modulate = Color.WHITE if on else Color("#b9b3e8")
		(t.get_meta("lb") as Label).add_theme_color_override("font_color", Color.WHITE if on else Color("#b9b3e8"))
	if i < _pages.size():
		_pages[i].scroll_to_top()


func on_enter(_args: Dictionary = {}) -> void:
	_refresh_colors()
	_refresh_cache()
	_ver_lbl.text = "BeatDrop v" + Store.version_text()
	fade_in(0.25)


# ------------------------------------------------------------------ util
func _caps(text: String) -> Label:
	return UI.spaced(text, 10, FX.MUT, 2)


func _seg(names: Array, cur: int, on_pick: Callable, h: float = 34.0) -> HBoxContainer:
	var hb := UI.hbox(6)
	var btns: Array = []
	for i in names.size():
		var b := UI.btn(String(names[i]), 12, FX.s_opt(i == cur), Vector2(0, h))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func():
			for j in btns.size():
				btns[j].style(FX.s_opt(j == i))
			on_pick.call(i))
		btns.append(b)
		hb.add_child(b)
	return hb


func _shape_prev(kind: int, on: bool) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(50, 28)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	c.set_meta("on", on)
	c.draw.connect(func():
		var col: Color = FX.PINK if bool(c.get_meta("on")) else Color("#8f88c7")
		var cx := c.size.x * 0.5
		var cy := c.size.y * 0.5
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0, 0, 0, 0)
		sb.border_color = col
		sb.set_border_width_all(3)
		sb.anti_aliasing = true
		var w := 46.0
		var h := 20.0
		var r := 10.0
		if kind == 1:
			w = 28.0
			h = 28.0
			r = 14.0
		elif kind == 2:
			w = 46.0
			h = 26.0
			r = 4.0
		elif kind == 3:
			w = 30.0
			h = 30.0
			r = 5.0
		sb.set_corner_radius_all(int(r))
		c.draw_style_box(sb, Rect2(cx - w / 2.0, cy - h / 2.0, w, h)))
	return c


## Baris kartu opsi bentuk. kinds: bentuk tiap kartu; names: nama; cur: indeks terpilih.
func _shape_row(kinds: Array, names: Array, cur: int, on_pick: Callable) -> HBoxContainer:
	var hb := UI.hbox(6)
	var cards: Array = []
	for i in kinds.size():
		var b := UI.btn("", 12, FX.s_opt(i == cur), Vector2(0, 64))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var body := b.make_body(4, 6, 4, 6)
		var v := UI.vbox(2)
		v.alignment = BoxContainer.ALIGNMENT_CENTER
		var pv := _shape_prev(int(kinds[i]), i == cur)
		v.add_child(pv)
		v.add_child(UI.label(String(names[i]), 11, FX.TX, "bold", HORIZONTAL_ALIGNMENT_CENTER))
		body.add_child(v)
		cards.append({"btn": b, "prev": pv})
		b.pressed.connect(func():
			for j in cards.size():
				cards[j]["btn"].style(FX.s_opt(j == i))
				cards[j]["prev"].set_meta("on", j == i)
				cards[j]["prev"].queue_redraw()
			on_pick.call(i))
		hb.add_child(b)
	return hb


func _slider_line(parent: Control, title: String, key: String, mn: float, mx: float, st: float, unit: String, ca: Color, cb: Color) -> void:
	var hb := UI.hbox(4)
	hb.add_child(_caps(title.to_upper()))
	var val := UI.label("", 12, FX.TX, "bold", HORIZONTAL_ALIGNMENT_RIGHT)
	val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(val)
	parent.add_child(hb)
	var sl := UI.WSlider.new()
	sl.setup(mn, mx, st, float(Store.SET[key]))
	sl.set_colors(ca, cb)
	var upd := func(v: float): val.text = "%d%s" % [int(v), unit]
	upd.call(sl.value)
	sl.value_changed.connect(func(v: float):
		Store.SET[key] = int(v)
		Store.save_soon()
		upd.call(v))
	parent.add_child(sl)


# ------------------------------------------------------------------ Colors
func _build_colors() -> void:
	var v := _page()
	var h := UI.hbox(16)
	v.add_child(h)
	_wheel = WWheel.new()
	_wheel.custom_minimum_size = Vector2(236, 236)
	_wheel.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	_wheel.picked.connect(_on_wheel)
	h.add_child(_wheel)
	var r := UI.vbox(7)
	r.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(r)
	var lh := UI.hbox(4)
	lh.add_child(_caps("LANES"))
	var hint := UI.label("tap a box to change its color", 9, FX.MUT, "medium", HORIZONTAL_ALIGNMENT_RIGHT)
	hint.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	lh.add_child(hint)
	r.add_child(lh)
	var lr := UI.hbox(6)
	for i in 5:
		var b := UI.btn(i_label(i), 13, FX.s_pill(), Vector2(0, 40), Color.WHITE)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func():
			_sel_lane = i
			_refresh_colors())
		_lanes.append(b)
		lr.add_child(b)
	r.add_child(lr)
	var sh := UI.hbox(4)
	sh.add_child(_caps("SATURATION"))
	_sat_val = UI.label("", 12, FX.TX, "bold", HORIZONTAL_ALIGNMENT_RIGHT)
	_sat_val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sh.add_child(_sat_val)
	r.add_child(sh)
	_sat_sl = UI.WSlider.new()
	_sat_sl.setup(0.0, 100.0, 1.0, 100.0)
	_sat_sl.value_changed.connect(func(val: float):
		var o: Dictionary = Store.hsl[_sel_lane]
		Store.set_lane_hsl(_sel_lane, float(o["h"]), val, float(o["l"]))
		Store.stats["colors"] = 1
		_refresh_colors()
		changed.emit())
	r.add_child(_sat_sl)
	r.add_child(_caps("QUICK PALETTES"))
	var g := GridContainer.new()
	g.columns = 2
	g.add_theme_constant_override("h_separation", 6)
	g.add_theme_constant_override("v_separation", 6)
	g.mouse_filter = Control.MOUSE_FILTER_PASS
	r.add_child(g)
	for nm in C.PALS:
		var chip := UI.btn("", 12, FX.s_pill(), Vector2(0, 30))
		chip.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var body := chip.make_body(8, 0, 8, 0)
		var hh := UI.hbox(7)
		hh.alignment = BoxContainer.ALIGNMENT_CENTER
		var gr := Gradient.new()
		var cs := PackedColorArray()
		for hx in C.PALS[nm]:
			cs.append(Color(hx))
		gr.colors = cs
		var offs := PackedFloat32Array()
		for k in cs.size():
			offs.append(float(k) / float(maxi(1, cs.size() - 1)))
		gr.offsets = offs
		var gt := GradientTexture1D.new()
		gt.gradient = gr
		gt.width = 48
		var sw_img := TextureRect.new()
		sw_img.texture = gt
		sw_img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		sw_img.custom_minimum_size = Vector2(32, 10)
		sw_img.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		sw_img.mouse_filter = Control.MOUSE_FILTER_IGNORE
		hh.add_child(sw_img)
		hh.add_child(UI.label(String(nm), 11, FX.TX, "bold"))
		body.add_child(hh)
		chip.pressed.connect(func():
			Store.set_palette(C.PALS[nm])
			_refresh_colors()
			changed.emit())
		g.add_child(chip)


func i_label(i: int) -> String:
	return "_" if i == 2 else String(C.LABELS[i])


func _on_wheel(hue: float, light: float) -> void:
	var o: Dictionary = Store.hsl[_sel_lane]
	Store.set_lane_hsl(_sel_lane, hue, float(o["s"]), light)
	Store.stats["colors"] = 1
	_refresh_colors()
	changed.emit()


func _refresh_colors() -> void:
	if _wheel == null:
		return
	for i in 5:
		var c: Color = Store.colors[i]
		var b = _lanes[i]
		var sel := i == _sel_lane
		b.style({"c1": c.lightened(0.18), "c2": c, "ang": 180.0, "bcol": Color(1, 1, 1, 0.95 if sel else 0.22), "bw": 3.0 if sel else 1.0, "rad": 12.0,
				"gcol": Color(c.r, c.g, c.b, 0.55 if sel else 0.0), "gsz": 8.0 if sel else 0.0})
		var dark := c.get_luminance() > 0.6
		b.label.add_theme_color_override("font_color", Color(0.05, 0.04, 0.12) if dark else Color.WHITE)
	var o: Dictionary = Store.hsl[_sel_lane]
	var cur: Color = Store.colors[_sel_lane]
	_wheel.set_state(float(o["h"]), float(o["l"]), float(o["s"]), cur)
	_sat_sl.set_value_silent(float(o["s"]))
	_sat_sl.set_colors(Color(0.6, 0.6, 0.66), cur)
	_sat_val.text = "%d%%" % int(o["s"])


# ------------------------------------------------------------------ Shapes
func _build_shapes() -> void:
	var v := _page()
	v.add_child(_caps("BEAT HOLE"))
	v.add_child(_shape_row([0, 1, 2, 3], C.HOLE_N, int(Store.SET["hole"]), _on_hole))
	v.add_child(UI.spacer(0, 4))
	v.add_child(_caps("NOTE SHAPE"))
	var kinds: Array = []
	var names: Array = []
	var cur := 0
	for k in C.NSHAPE_OPTS.size():
		var id := int(C.NSHAPE_OPTS[k][0])
		kinds.append(0 if id == 0 else (2 if id == 2 else 3))
		names.append(C.NSHAPE_OPTS[k][1])
		if id == int(Store.SET["nshape"]):
			cur = k
	v.add_child(_shape_row(kinds, names, cur, _on_nshape))
	v.add_child(UI.label("Changes apply the next time you start a song.", 10, FX.MUT))


func _on_hole(i: int) -> void:
	Store.SET["hole"] = i
	Store.save_soon()
	changed.emit()


func _on_nshape(i: int) -> void:
	Store.SET["nshape"] = int(C.NSHAPE_OPTS[i][0])
	Store.save_soon()
	changed.emit()


# ------------------------------------------------------------------ Camera
func _build_camera() -> void:
	var v := _page()
	var hb := UI.hbox(4)
	hb.add_child(_caps("TILTED CAMERA ANGLE"))
	_tilt_val = UI.label("", 12, FX.TX, "bold", HORIZONTAL_ALIGNMENT_RIGHT)
	_tilt_val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(_tilt_val)
	v.add_child(hb)
	_tilt_sl = UI.WSlider.new()
	_tilt_sl.setup(0.0, 100.0, 5.0, float(Store.SET["tilt"]))
	_tilt_sl.set_colors(Color("#38e6ff"), Color("#3a8bff"))
	_tilt_sl.value_changed.connect(func(val: float):
		Store.SET["tilt"] = int(val)
		Store.save_soon()
		_upd_tilt()
		changed.emit())
	v.add_child(_tilt_sl)
	v.add_child(UI.label("0% = straight (lightest) · higher tilts further back", 10, FX.MUT))
	_tilt_prev = Control.new()
	_tilt_prev.custom_minimum_size = Vector2(0, 110)
	_tilt_prev.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_tilt_prev.draw.connect(_draw_tilt)
	v.add_child(_tilt_prev)
	_upd_tilt()


func _upd_tilt() -> void:
	var t := int(Store.SET["tilt"])
	_tilt_val.text = "%d%%" % t
	if _tilt_prev != null:
		_tilt_prev.queue_redraw()


func _draw_tilt() -> void:
	var t := float(Store.SET["tilt"]) / 100.0
	var w := minf(300.0, _tilt_prev.size.x - 20.0)
	var h := 96.0
	var cx := _tilt_prev.size.x * 0.5
	var base_y := _tilt_prev.size.y - 6.0
	var ang := t * 0.95
	var persp := 260.0
	var top_s := persp / (persp + h * sin(ang))
	var hh := h * cos(ang) * (1.0 + top_s) * 0.5
	var bw := w
	var tw := w * top_s
	var pts := PackedVector2Array([Vector2(cx - tw / 2.0, base_y - hh), Vector2(cx + tw / 2.0, base_y - hh), Vector2(cx + bw / 2.0, base_y), Vector2(cx - bw / 2.0, base_y)])
	var cols := PackedColorArray([Color(0.486, 0.36, 1.0, 0.55), Color(0.486, 0.36, 1.0, 0.55), Color(1.0, 0.24, 0.5, 0.55), Color(1.0, 0.24, 0.5, 0.55)])
	_tilt_prev.draw_polygon(pts, cols)
	for i in 11:
		var u := float(i) / 10.0
		var xt := cx - tw / 2.0 + tw * u
		var xb := cx - bw / 2.0 + bw * u
		_tilt_prev.draw_line(Vector2(xt, base_y - hh), Vector2(xb, base_y), Color(1, 1, 1, 0.28), 1.5)


# ------------------------------------------------------------------ Effects
func _build_effects() -> void:
	var v := _page()
	var hb := UI.hbox(8)
	hb.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(hb)
	_effect_card(hb, "sparkle", "Particles", "Sparks when you hit notes", "parts")
	_effect_card(hb, "sun", "Lane glow", "Lanes light up when pressed", "glow")
	_effect_card(hb, "waves", "Vibration", "Vibrate phone on note hits", "vib")


func _effect_card(parent: Control, icon: String, title: String, desc: String, key: String) -> void:
	var b := UI.btn("", 12, FX.s_opt(false), Vector2(0, 170))
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var body := b.make_body(8, 10, 8, 10)
	var v := UI.vbox(6)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	var ic := UI.icon_rect(icon, 30, Color("#8f88c7"))
	ic.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	v.add_child(ic)
	v.add_child(UI.label(title, 14, FX.TX, "bold", HORIZONTAL_ALIGNMENT_CENTER))
	var d := UI.label(desc, 10, FX.MUT, "medium", HORIZONTAL_ALIGNMENT_CENTER)
	d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	v.add_child(d)
	var sw := UI.WSwitch.new()
	sw.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	sw.set_on(bool(Store.SET[key]))
	v.add_child(sw)
	body.add_child(v)
	var apply := func():
		var on: bool = sw.on
		b.style({"c1": Color(0.059, 0.169, 0.141, 0.9), "c2": Color(0.075, 0.125, 0.227, 0.9), "ang": 135.0, "bcol": FX.GREEN, "bw": 2.0, "rad": 14.0,
				"gcol": Color(0.18, 0.9, 0.65, 0.3), "gsz": 10.0} if on else FX.s_opt(false))
		ic.modulate = FX.GREEN if on else Color("#8f88c7")
	apply.call()
	b.pressed.connect(func():
		sw.toggle()
		Store.SET[key] = sw.on
		Store.save_soon()
		apply.call()
		changed.emit())


# ------------------------------------------------------------------ Graphics
func _build_graphics() -> void:
	var v := _page()
	v.add_child(_caps("GAME RESOLUTION"))
	var names: Array = []
	var cur := 1
	for k in RES_KEYS.size():
		names.append(C.RES_NAME[RES_KEYS[k]])
		if RES_KEYS[k] == int(Store.SET["res"]):
			cur = k
	v.add_child(_seg(names, cur, _on_res))
	v.add_child(UI.label("HD 720p is sharp and smooth. Use Saver if your phone drops frames.", 10, FX.MUT))
	var aq := UI.btn("", 12, FX.s_opt(false), Vector2(0, 44))
	var ab := aq.make_body(12, 4, 12, 4)
	var ah := UI.hbox(8)
	var av := UI.vbox(0)
	av.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	av.alignment = BoxContainer.ALIGNMENT_CENTER
	av.add_child(UI.label("Adaptive quality", 13, FX.TX, "bold"))
	av.add_child(UI.label("Lowers render size if FPS dips, restores when stable", 10, FX.MUT))
	ah.add_child(av)
	var asw := UI.WSwitch.new()
	asw.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	asw.set_on(bool(Store.SET["aq"]))
	ah.add_child(asw)
	ab.add_child(ah)
	aq.pressed.connect(func():
		asw.toggle()
		Store.SET["aq"] = asw.on
		Store.save_soon())
	v.add_child(aq)
	v.add_child(UI.label("Frame rate is locked to 60 FPS (VSync) for stable timing.", 10, Color(1, 1, 1, 0.4)))
	v.add_child(_caps("NOTE GENERATOR"))
	v.add_child(_seg(["V1 Beat", "V2 Bass (Beta)", "V3 Melody (Beta)"], int(Store.SET["gen"]) - 1, _on_gen))
	_v2_box = UI.vbox(4)
	_slider_line(_v2_box, "Sensitivity", "v2th", 0.0, 100.0, 5.0, "", Color("#ff9f1c"), Color("#ff3d81"))
	_slider_line(_v2_box, "Min gap between notes", "v2cd", 100.0, 600.0, 10.0, " ms", Color("#38e6ff"), Color("#3a8bff"))
	_v2_box.visible = int(Store.SET["gen"]) == 2
	v.add_child(_v2_box)
	_v3_box = UI.vbox(4)
	_slider_line(_v3_box, "Sensitivity", "v3th", 0.0, 100.0, 5.0, "", Color("#ff9f1c"), Color("#ff3d81"))
	_slider_line(_v3_box, "Hold note length", "v3hl", 20.0, 150.0, 5.0, "%", Color("#38e6ff"), Color("#3a8bff"))
	_v3_box.visible = int(Store.SET["gen"]) == 3
	v.add_child(_v3_box)
	v.add_child(UI.label("First analysis of a song can take a while; results are cached on this device.", 10, FX.MUT))
	v.add_child(_caps("STORAGE"))
	_cache_lbl = UI.label("", 11, FX.TX)
	v.add_child(_cache_lbl)
	var cb := UI.btn("Clear analysis cache", 12, FX.s_pill(), Vector2(0, 34))
	cb.pressed.connect(func():
		Store.cache_clear()
		_refresh_cache()
		toast_req.emit("Cache cleared"))
	v.add_child(cb)
	v.add_child(_caps("ABOUT"))
	_ver_lbl = UI.label("", 11, FX.MUT)
	v.add_child(_ver_lbl)


func _on_res(i: int) -> void:
	Store.SET["res"] = RES_KEYS[i]
	Store.save_soon()
	changed.emit()


func _on_gen(i: int) -> void:
	Store.SET["gen"] = i + 1
	Store.save_soon()
	_v2_box.visible = i == 1
	_v3_box.visible = i == 2


func _refresh_cache() -> void:
	if _cache_lbl == null:
		return
	var total := 0
	for e in Store.library:
		total += int(e["bytes"])
	_cache_lbl.text = "Songs: %d (%.1f MB)  ·  Analysis cache: %.1f MB" % [Store.library.size(), float(total) / 1048576.0, float(Store.cache_bytes()) / 1048576.0]
