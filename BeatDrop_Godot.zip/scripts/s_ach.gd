extends "res://scripts/s_base.gd"
## Daftar prestasi (54). Yang sudah terbuka tampil berwarna di atas.

const C = preload("res://scripts/consts.gd")

var _scroll
var _sub: Label


func _ready() -> void:
	var col := UI.vbox(6)
	mc.add_child(col)
	var h := make_header("Achievements", "", "menu")
	_sub = h.get_meta("sub")
	col.add_child(h)
	_scroll = UI.WScroll.new()
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(_scroll)


func on_enter(_args: Dictionary = {}) -> void:
	UI.clear_children(_scroll.content)
	_sub.text = "%d / %d unlocked" % [Store.achv.size(), C.ACHV.size()]
	var order: Array = []
	for a in C.ACHV:
		if Store.achv.has(a[0]):
			order.append(a)
	for a in C.ACHV:
		if not Store.achv.has(a[0]):
			order.append(a)
	for a in order:
		_scroll.content.add_child(_row(a, Store.achv.has(a[0])))
	_scroll.scroll_to_top()
	fade_in(0.25)


func _row(a: Array, got: bool) -> Control:
	var tc := Color(C.TIER_C[int(a[3])])
	var st := FX.s_row(false)
	if got:
		st = {"c1": FX.rgba(54, 44, 128, 0.55), "c2": FX.rgba(20, 16, 50, 0.75), "ang": 100.0, "bcol": Color(tc.r, tc.g, tc.b, 0.7), "bw": 1.5, "rad": 14.0}
	var p := UI.card(st, 12, 7, 12, 7)
	p.custom_minimum_size = Vector2(0, 44)
	var h := UI.hbox(12)
	p.body.add_child(h)
	var ic := UI.icon_rect("trophy" if got else "lock", 22, tc if got else Color(1, 1, 1, 0.28))
	ic.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	h.add_child(ic)
	var v := UI.vbox(0)
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_child(UI.label(String(a[1]), 13, FX.TX if got else FX.MUT, "bold"))
	v.add_child(UI.label(String(a[2]), 10, FX.MUT))
	h.add_child(v)
	var tl := UI.label(String(C.TIER_N[int(a[3])]), 11, tc if got else Color(1, 1, 1, 0.3), "bold")
	tl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	h.add_child(tl)
	return p
