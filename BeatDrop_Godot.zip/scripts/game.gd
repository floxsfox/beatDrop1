extends Node
## Logika permainan (port dari bagian "Permainan" di index.html).
## Koordinat game memakai "satuan virtual" bertinggi 400 (lihat consts.GAME_H) sehingga layout
## identik di semua resolusi layar; render sebenarnya di-skala oleh SubViewport.

signal finished(failed: bool, run: Dictionary)
signal toast(msg: String)
signal quality_changed(q: float)
signal state_changed(new_state: String)

const C = preload("res://scripts/consts.gd")
const MAXP := 160
const MAXF := 240

# ---- layar / layout (satuan virtual)
var W := 889.0
var H := 400.0
var S := 1.0
var L := 0.0
var LX := 0.0
var LW := 0.0
var HY := 300.0
var NH := 26.0
var SQ := 60.0
var RB := 40.0
var NHt := 26.0
var HHt := 26.0
var PY := 0.0
var NW := 100.0
var sb_top := 0.0
var sb_bot := 0.0
var SP := 1.0
var APP := 2.0
var TK := 0.0
var ts := 1.8                      # skala tekstur terhadap satuan virtual

# ---- tekstur game
var note_mask: ImageTexture
var fluid_tex: GradientTexture2D
var glow_tex: GradientTexture2D

# ---- status
var state := "idle"                # idle | play | pause | count | done
var player: AudioStreamPlayer
var song_id := ""
var song_name := ""
var diff := 0
var gen := 1
var dur := 0.0
var v2_play := false

# ---- not (array paralel; lebih ringan daripada Dictionary)
var n_t := PackedFloat32Array()
var n_d := PackedFloat32Array()
var n_l := PackedInt32Array()
var n_st := PackedInt32Array()     # 0 menunggu, 1 ditahan, 2 selesai
var n_fl := PackedInt32Array()     # bit1 miss, bit2 patah, bit4 lahir
var n_count := 0
var ni := 0
var si := 0

# ---- skor
var score := 0
var combo := 0
var max_c := 0
var cnt := [0, 0, 0, 0]
var acc_s := 0.0
var hp := 100.0
var hp_g := 100.0
var holds_done := 0
var dsc := 0.0
var cp := 0.0
var pad := [0.0, 0.0, 0.0, 0.0, 0.0]
var down := [0, 0, 0, 0, 0]
var pop_text := ""
var pop_color := Color.WHITE
var pop_start := 0
var cd_text := ""                  # hitung mundur saat resume
var pre_num := 0                   # angka hitung mundur awal (3,2,1) atau 0
var pul := 0.0
var hold_now := -3.0

# ---- partikel (struct-of-arrays)
var p_x := PackedFloat32Array()
var p_y := PackedFloat32Array()
var p_vx := PackedFloat32Array()
var p_vy := PackedFloat32Array()
var p_l := PackedFloat32Array()
var p_c := PackedInt32Array()
var p_i := 0
var f_x := PackedFloat32Array()
var f_y := PackedFloat32Array()
var f_vx := PackedFloat32Array()
var f_vy := PackedFloat32Array()
var f_s := PackedFloat32Array()
var f_l := PackedFloat32Array()
var f_ph := PackedFloat32Array()
var f_sp := PackedFloat32Array()
var f_c := PackedInt32Array()
var f_i := 0

# ---- jam audio
var audio_started := false
var t_go_usec := 0
var _pre_remain := 3000000
var lat := 0.0
var _has_last := false
var _last_cur := 0.0
var _last_wall := 0
var _last_pos := -1.0
var _last_prog_usec := 0
var _cd_sound := -1
var _go_played := false
var _audio_ended := false
var _audio_play_usec := 0

# ---- kualitas adaptif
var Q := 1.0
var _q_fail := 99.0
var _fq := 0
var _fema := 0.0
var _good_frames := 0

var layers_static: Array = []
var layers_dyn: Array = []


func _ready() -> void:
	player = AudioStreamPlayer.new()
	player.bus = Sfx.music_bus_name
	add_child(player)
	player.finished.connect(func(): _audio_ended = true)
	for i in MAXP:
		p_x.append(0.0)
		p_y.append(0.0)
		p_vx.append(0.0)
		p_vy.append(0.0)
		p_l.append(0.0)
		p_c.append(0)
	for i in MAXF:
		f_x.append(0.0)
		f_y.append(0.0)
		f_vx.append(0.0)
		f_vy.append(0.0)
		f_s.append(0.0)
		f_l.append(0.0)
		f_ph.append(0.0)
		f_sp.append(0.0)
		f_c.append(0)
	_build_shared_textures()


# ------------------------------------------------------------------ layout

func acc_k() -> float:
	return float(C.ACC_K[clampi(int(Store.SET["acc"]), 0, 2)])


func set_sp() -> void:
	var base: float = C.WAKTU_PERJALANAN_NOT if gen >= 2 else float(C.DF[diff]["ap"])
	APP = base / clampf(float(Store.SET["spd"]), 0.4, 2.0)
	SP = (HY + 30.0) / APP


func layout(vw: float, vh: float, inset_bottom: float, inset_top: float, tex_scale: float) -> void:
	W = vw
	H = vh
	sb_top = inset_top
	sb_bot = inset_bottom
	ts = tex_scale
	S = clampf(H / 430.0, 0.7, 1.25)
	var tilt: bool = int(Store.SET["tilt"]) > 0
	L = minf(minf(W * (0.94 if tilt else 0.74), H * (2.6 if tilt else 1.75)), 1100.0 if tilt else 760.0)
	LX = (W - L) / 2.0
	LW = L / 5.0
	HY = H - maxf(78.0, minf(150.0, H * 0.25)) - sb_bot
	NH = maxf(20.0, minf(30.0, H * 0.065))
	NW = roundf(LW * 0.84)
	SQ = roundf(minf(minf(NW * 0.9, H * 0.2), 120.0))
	RB = roundf(minf(NW * 0.58, H * 0.14))
	var ns := int(Store.SET["nshape"])
	var hs := int(Store.SET["hole"])
	NHt = SQ if ns == 1 else (RB if ns == 2 else NH)
	HHt = SQ if hs == 3 else (RB if hs == 2 else NH)
	PY = roundf(HY + maxf(NH + 10.0, maxf(NHt, HHt) / 2.0 + 12.0))
	TK = float(Store.SET["tilt"]) / 100.0 * 1.5
	set_sp()
	_build_note_mask()
	redraw_static()


func redraw_static() -> void:
	for n in layers_static:
		n.queue_redraw()


func _build_shared_textures() -> void:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.3, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0.55), Color(1, 1, 1, 0)])
	fluid_tex = GradientTexture2D.new()
	fluid_tex.gradient = g
	fluid_tex.fill = GradientTexture2D.FILL_RADIAL
	fluid_tex.fill_from = Vector2(0.5, 0.5)
	fluid_tex.fill_to = Vector2(1.0, 0.5)
	fluid_tex.width = 64
	fluid_tex.height = 64
	var g2 := Gradient.new()
	g2.offsets = PackedFloat32Array([0.0, 1.0])
	g2.colors = PackedColorArray([Color(0.486, 0.36, 1.0, 0.6), Color(0.486, 0.36, 1.0, 0.0)])
	glow_tex = GradientTexture2D.new()
	glow_tex.gradient = g2
	glow_tex.fill = GradientTexture2D.FILL_RADIAL
	glow_tex.fill_from = Vector2(0.5, 0.5)
	glow_tex.fill_to = Vector2(1.0, 0.5)
	glow_tex.width = 128
	glow_tex.height = 128


## Satu "mask" putih bersudut membulat; warna diberikan lewat warna vertex saat menggambar not.
func _build_note_mask() -> void:
	var ns := int(Store.SET["nshape"])
	var bw := SQ if ns == 1 else NW
	var bh := NHt
	var w := maxi(8, int(ceil(bw * ts)))
	var h := maxi(8, int(ceil(bh * ts)))
	var box := ns > 0
	var r := (minf(8.0, bh * 0.14) if box else bh * 0.45) * ts
	r = minf(r, minf(float(w), float(h)) / 2.0)
	var img := Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	var hw := float(w) / 2.0
	var hh := float(h) / 2.0
	for y in h:
		var py := float(y) + 0.5 - hh
		var qy := absf(py) - (hh - r)
		for x in w:
			var px := float(x) + 0.5 - hw
			var qx := absf(px) - (hw - r)
			var ox := maxf(qx, 0.0)
			var oy := maxf(qy, 0.0)
			var d := sqrt(ox * ox + oy * oy) + minf(maxf(qx, qy), 0.0) - r
			img.set_pixel(x, y, Color(1, 1, 1, clampf(0.5 - d, 0.0, 1.0)))
	note_mask = ImageTexture.create_from_image(img)


# ------------------------------------------------------------------ proyeksi kamera miring

func P(x: float, y: float) -> Vector2:
	if TK <= 0.0:
		return Vector2(x, y)
	var d := clampf((H - y) / H, 0.0, 1.0)
	var s := 1.0 / (1.0 + TK * d)
	return Vector2(W * 0.5 + (x - W * 0.5) * s, H - H * (1.0 + TK) * d / (1.0 + TK * d))


func Pscale(y: float) -> float:
	if TK <= 0.0:
		return 1.0
	var d := clampf((H - y) / H, 0.0, 1.0)
	return 1.0 / (1.0 + TK * d)


## Titik layar (virtual) -> lajur 0..4, atau -1.
func lane_at(x: float, y: float) -> int:
	var xx := x
	if TK > 0.0:
		var ds := clampf((H - y) / H, 0.0, 1.0)
		var d := ds / ((1.0 + TK) - TK * ds)
		xx = W * 0.5 + (x - W * 0.5) * (1.0 + TK * d)
	var l := int(floor((xx - LX) / LW))
	return -1 if (l < 0 or l > 4) else l


# ------------------------------------------------------------------ mulai / henti

func start_song(id: String, nm: String, stream: AudioStream, notes: Array, diff_i: int, gen_used: int) -> void:
	stop_audio()
	song_id = id
	song_name = nm
	diff = diff_i
	gen = gen_used
	dur = stream.get_length()
	v2_play = gen >= 2
	_pack(notes)
	ni = 0
	si = 0
	score = 0
	combo = 0
	max_c = 0
	cnt = [0, 0, 0, 0]
	acc_s = 0.0
	hp = 100.0
	hp_g = 100.0
	holds_done = 0
	dsc = 0.0
	cp = 0.0
	pop_text = ""
	cd_text = ""
	for i in 5:
		pad[i] = 0.0
		down[i] = 0
	for i in MAXP:
		p_l[i] = 0.0
	for i in MAXF:
		f_l[i] = 0.0
	set_sp()
	TK = float(Store.SET["tilt"]) / 100.0 * 1.5
	player.stream = stream
	player.volume_db = 0.0
	lat = clampf(AudioServer.get_output_latency(), 0.0, 0.6)
	audio_started = false
	_go_played = false
	_audio_ended = false
	_cd_sound = -1
	t_go_usec = Time.get_ticks_usec() + 3000000
	_has_last = false
	hold_now = -3.0
	_last_pos = -1.0
	_last_prog_usec = Time.get_ticks_usec()
	_fq = 0
	_fema = 0.0
	_good_frames = 0
	_q_fail = 99.0
	if not is_equal_approx(Q, 1.0):
		Q = 1.0
		quality_changed.emit(Q)
	_set_state("play")


func _pack(notes: Array) -> void:
	n_count = notes.size()
	n_t.resize(n_count)
	n_d.resize(n_count)
	n_l.resize(n_count)
	n_st.resize(n_count)
	n_fl.resize(n_count)
	for i in n_count:
		var d: Dictionary = notes[i]
		n_t[i] = float(d["t"])
		n_d[i] = float(d["dur"])
		n_l[i] = int(d["l"])
		n_st[i] = 0
		n_fl[i] = 0


func _set_state(s: String) -> void:
	state = s
	state_changed.emit(s)


func stop_audio() -> void:
	if player != null:
		player.stop()
		player.stream_paused = false


func to_idle() -> void:
	stop_audio()
	_set_state("idle")


# ------------------------------------------------------------------ jam

func _raw_time() -> float:
	if not audio_started:
		return float(Time.get_ticks_usec() - t_go_usec) / 1000000.0
	return player.get_playback_position() + AudioServer.get_time_since_last_mix() - lat


## Posisi lagu (detik). Mengikuti jam audio 1:1, tetapi langkah maju dibatasi agar mulus dan tak pernah mundur.
func cur() -> float:
	var wall := Time.get_ticks_usec()
	var raw := _raw_time() - float(Store.sync_ms) / 1000.0
	if not _has_last:
		_last_cur = raw
		_last_wall = wall
		_has_last = true
		return raw
	var max_step := maxf(0.0, float(wall - _last_wall) / 1000000.0) * 1.1 + 0.002
	var d := raw - _last_cur
	if d < 0.0:
		d = 0.0
	elif d > max_step:
		d = max_step
	_last_cur += d
	_last_wall = wall
	return _last_cur


# ------------------------------------------------------------------ jeda / lanjut

func pause_game() -> void:
	if state != "play":
		return
	_pre_remain = t_go_usec - Time.get_ticks_usec()
	if audio_started:
		player.stream_paused = true
	_set_state("pause")
	Store.stats["pauses"] += 1
	Store.save_soon()


func resume_game() -> void:
	if state != "pause":
		return
	_set_state("count")
	for n in [3, 2, 1]:
		cd_text = str(n)
		await get_tree().create_timer(0.65).timeout
		if state != "count":
			cd_text = ""
			return
	cd_text = ""
	if audio_started:
		player.stream_paused = false
	else:
		t_go_usec = Time.get_ticks_usec() + maxi(0, _pre_remain)
	_has_last = false
	_last_prog_usec = Time.get_ticks_usec()
	_last_pos = -1.0
	_set_state("play")


# ------------------------------------------------------------------ input

func press(l: int) -> void:
	down[l] += 1
	pad[l] = 1.0
	if state != "play":
		return
	fluid(l, 6)
	var now := cur()
	var ka := acc_k()
	var best := -1
	var bd := 0.2 * ka
	var i := ni
	while i < n_count and n_t[i] < now + 0.25:
		if n_l[i] == l and n_st[i] == 0:
			var d := absf(n_t[i] - now)
			if d < bd:
				bd = d
				best = i
		i += 1
	if best < 0:
		return
	var q := 2 if bd <= 0.07 * ka else (1 if bd <= 0.12 * ka else 0)
	_judge(q, l)
	n_st[best] = 1 if n_d[best] > 0.0 else 2


func release(l: int) -> void:
	down[l] = maxi(0, down[l] - 1)
	if down[l] > 0 or state != "play":
		return
	var now := cur()
	var i := ni
	while i < n_count and n_t[i] < now + 0.25:
		if n_l[i] == l and n_st[i] == 1:
			n_st[i] = 2
			if now < n_t[i] + n_d[i] - 0.25:
				n_fl[i] |= 2
				_fail("PATAH")
			else:
				score += 150
				holds_done += 1
				spawn(l, 12)
		i += 1


func _judge(q: int, l: int) -> void:
	cnt[q] += 1
	combo += 1
	max_c = maxi(max_c, combo)
	cp = 1.0
	var pts: Array = [100, 200, 300]
	score += roundi(float(pts[q]) * (1.0 + float(mini(combo, 100)) / 100.0))
	var wq: Array = [0.5, 0.8, 1.0]
	acc_s += float(wq[q])
	hp = minf(100.0, hp + (2.0 if q == 2 else (1.0 if q == 1 else 0.0)))
	Sfx.hit(q)
	if Store.SET["vib"]:
		Input.vibrate_handheld(15)
	var names: Array = ["GOOD", "GREAT", "PERFECT"]
	var cols: Array = [Color("#9e98cc"), Color("#2ee6a6"), Color("#ffd24a")]
	pop_text = names[q]
	pop_color = cols[q]
	pop_start = Time.get_ticks_msec()
	spawn(l, 14 if q > 0 else 6)


func _fail(txt: String) -> void:
	combo = 0
	hp -= 5.0 if txt == "PATAH" else 8.0
	Sfx.play("miss")
	if hp <= 0.0:
		hp = 0.0
		_finish(true)
		return
	pop_text = txt
	pop_color = Color("#ff4d6d")
	pop_start = Time.get_ticks_msec()


# ------------------------------------------------------------------ partikel

func spawn(l: int, n: int) -> void:
	if not Store.SET["parts"]:
		return
	fluid(l, int(ceil(float(n) / 2.0)))
	var cx := LX + float(l) * LW + LW / 2.0
	for k in n:
		var i := p_i
		p_i = (p_i + 1) % MAXP
		p_x[i] = cx
		p_y[i] = HY
		p_vx[i] = (randf() - 0.5) * 340.0
		p_vy[i] = -randf() * 320.0 - 40.0
		p_l[i] = 1.0
		p_c[i] = l


func fluid(l: int, n: int) -> void:
	if not Store.SET["parts"]:
		return
	var cx := LX + float(l) * LW + LW / 2.0
	for k in n:
		var i := f_i
		f_i = (f_i + 1) % MAXF
		f_x[i] = cx + (randf() - 0.5) * LW * 0.7
		f_y[i] = HY + (randf() - 0.5) * 8.0
		f_vx[i] = (randf() - 0.5) * 26.0
		f_vy[i] = -(50.0 + randf() * 130.0)
		f_s[i] = 0.3 + randf() * 0.7
		f_l[i] = 1.0
		f_ph[i] = randf() * 6.3
		f_sp[i] = 0.55 + randf() * 0.8
		f_c[i] = l


func _step_particles(dt: float) -> void:
	for i in MAXP:
		if p_l[i] <= 0.0:
			continue
		p_l[i] -= dt * 2.2
		p_vy[i] += 700.0 * dt
		p_x[i] += p_vx[i] * dt
		p_y[i] += p_vy[i] * dt
	for i in MAXF:
		if f_l[i] <= 0.0:
			continue
		f_l[i] -= dt * f_sp[i] * 0.9
		f_ph[i] += dt * 4.0
		f_vy[i] *= 1.0 - dt * 0.5
		f_x[i] += (f_vx[i] + sin(f_ph[i]) * 18.0) * dt
		f_y[i] += f_vy[i] * dt


# ------------------------------------------------------------------ frame

func _process(delta: float) -> void:
	if state == "idle" or state == "done":
		return
	var dt := minf(0.05, delta)
	if state == "play":
		_adaptive_quality(delta)
	var now := hold_now
	if state == "play":
		var tick := float(Time.get_ticks_usec() - t_go_usec) / 1000000.0
		if not audio_started:
			# hitung mundur 3-2-1 sebelum lagu mulai
			var n2 := mini(3, int(ceil(-tick)))
			if tick < 0.0:
				pre_num = n2
				if n2 != _cd_sound:
					_cd_sound = n2
					Sfx.play("count")
			else:
				pre_num = 0
				audio_started = true
				_audio_play_usec = Time.get_ticks_usec()
				player.play()
				if not _go_played:
					_go_played = true
					Sfx.play("go")
		now = cur()
		hold_now = now
		_update(now)
		# Akhir lagu: jam audio berhenti saat stream selesai, jadi jangan bergantung pada waktu > durasi.
		if state == "play" and audio_started:
			var since := Time.get_ticks_usec() - _audio_play_usec
			if _audio_ended or (since > 1500000 and not player.playing and not player.stream_paused):
				_audio_ended = false
				_finish(false)
		if state == "play" and audio_started and now > 1.0 and now < dur - 0.5:
			var pos := player.get_playback_position()
			var u := Time.get_ticks_usec()
			if pos > _last_pos + 0.0001:
				_last_pos = pos
				_last_prog_usec = u
			elif u - _last_prog_usec > 2500000:
				toast.emit("Audio stalled, game paused. Press Resume.")
				pause_game()
		if audio_started:
			pul += (Sfx.bass_level() - pul) * (1.0 - exp(-dt * 16.0))
	else:
		pul += (0.0 - pul) * (1.0 - exp(-dt * 6.0))
	# pad
	for l in 5:
		if down[l] > 0:
			pad[l] = 1.0
			if state == "play" and randf() < dt * 16.0:
				fluid(l, 1)
		else:
			pad[l] = maxf(0.0, pad[l] - dt * 5.0)
	cp = maxf(0.0, cp - dt * 6.0)
	dsc += (float(score) - dsc) * (1.0 - exp(-dt * 10.0))
	if absf(float(score) - dsc) < 1.0:
		dsc = float(score)
	if hp > hp_g:
		hp_g = hp
	else:
		hp_g += (hp - hp_g) * (1.0 - exp(-dt * 2.5))
	_step_particles(dt)
	for n in layers_dyn:
		n.queue_redraw()


func _update(now: float) -> void:
	if v2_play:
		while si < n_count and now >= float(n_t[si]) - APP:
			n_fl[si] |= 4
			si += 1
	var ka := acc_k()
	var i := ni
	while i < n_count and n_t[i] < now + 0.25:
		if n_st[i] == 0 and now - n_t[i] > 0.2 * ka:
			n_st[i] = 2
			n_fl[i] |= 1
			cnt[3] += 1
			_fail("MISS")
			if state != "play":
				return
		elif n_st[i] == 1 and now >= n_t[i] + n_d[i]:
			n_st[i] = 2
			score += 150
			holds_done += 1
			combo += 1
			max_c = maxi(max_c, combo)
			spawn(n_l[i], 12)
		i += 1
	while ni < n_count and float(n_t[ni] + n_d[ni]) < now - (H - HY) / SP - 0.3:
		ni += 1
	if now > dur + 0.2:
		_finish(false)


func _adaptive_quality(delta: float) -> void:
	if not Store.SET["aq"]:
		return
	_fq += 1
	_fema = delta if _fema == 0.0 else _fema + (delta - _fema) * 0.05
	if _fema < 0.0172:
		_good_frames += 1
	else:
		_good_frames = 0
	if _fq < 90:
		return
	_fq = 0
	if _fema > 0.0215 and Q > 0.7:
		_q_fail = Q                  # level ini gagal; jangan naik lagi ke sana pada lagu ini
		Q = maxf(0.7, Q - 0.15)
		_fema = 0.0
		_good_frames = 0
		quality_changed.emit(Q)
	elif _good_frames > 900 and Q < 1.0 and Q + 0.15 < _q_fail - 0.001:
		Q = minf(1.0, Q + 0.15)
		_fema = 0.0
		_good_frames = 0
		quality_changed.emit(Q)


func accuracy() -> float:
	var tot := int(cnt[0]) + int(cnt[1]) + int(cnt[2]) + int(cnt[3])
	return acc_s / float(tot) if tot > 0 else 1.0


func _finish(failed: bool) -> void:
	if state == "done":
		return
	_set_state("done")
	if failed:
		player.stop()
	var tot := int(cnt[0]) + int(cnt[1]) + int(cnt[2]) + int(cnt[3])
	var acc := acc_s / float(tot) if tot > 0 else 0.0
	var g := "F"
	if failed:
		g = "F"
	elif acc >= 0.985 and int(cnt[3]) == 0:
		g = "S+"
	elif acc >= 0.95:
		g = "S"
	elif acc >= 0.92:
		g = "A+"
	elif acc >= 0.88:
		g = "A"
	elif acc >= 0.83:
		g = "B+"
	elif acc >= 0.78:
		g = "B"
	elif acc >= 0.65:
		g = "C"
	var run := {
		"id": song_id, "name": song_name, "diff": diff, "cnt": cnt.duplicate(), "maxC": max_c, "score": score,
		"acc": acc, "grade": g, "failed": failed, "hp": hp, "holds": holds_done,
	}
	finished.emit(failed, run)
