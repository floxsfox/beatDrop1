extends "res://scripts/s_base.gd"
## "Set Up Game": sampul + koleksi nilai (F..S+), pilih level / akurasi / kecepatan / sinkron, START.

const C = preload("res://scripts/consts.gd")
const ACC_ON := {"c1": Color(0.227, 0.165, 0.031, 0.95), "c2": Color(0.227, 0.165, 0.031, 0.95), "bcol": Color("#ffd24a"), "bw": 2.0, "rad": 12.0,
		"gcol": Color(1.0, 0.82, 0.29, 0.35), "gsz": 10.0}
const DIFF_COL := [Color("#2ee6a6"), Color("#3aa0ff"), Color("#ff3d81")]

var song_id := ""
var sel_diff := 1
var _counts: Array = []
var _rows: Array = []
var _acc_btns: Array = []
var _chips: Array = []
var _spd_sl
var _sync_sl
var _spd_val: Label
var _sync_val: Label
var _acc_val: Label
var _name: Label
var _meta: Label
var _cover_img: TextureRect
var _cover_note: TextureRect


func _ready() -> void:
	var main := UI.hbox(16)
	mc.add_child(main)
	# ---------------- kiri: sampul, nama, koleksi nilai
	var left := UI.vbox(6)
	left.custom_minimum_size = Vector2(158, 0)
	main.add_child(left)
	var cover := UI.WPanel.new()
	cover.custom_minimum_size = Vector2(150, 150)
	cover.style({"c1": Color("#3b2c86"), "c2": Color("#ff3d81"), "ang": 135.0, "bcol": Color(1, 1, 1, 0.3), "bw": 2.0, "rad": 22.0,
			"gcol": Color(1.0, 0.24, 0.5, 0.35), "gsz": 12.0})
	left.add_child(cover)
	_cover_note = UI.icon_rect("note", 64, Color(1, 1, 1, 0.55))
	_cover_note.set_anchors_preset(Control.PRESET_CENTER)
	_cover_note.offset_left = -32.0
	_cover_note.offset_right = 32.0
	_cover_note.offset_top = -46.0
	_cover_note.offset_bottom = 18.0
	cover.add_child(_cover_note)
	_cover_img = TextureRect.new()
	_cover_img.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_cover_img.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	_cover_img.set_anchors_preset(Control.PRESET_FULL_RECT)
	_cover_img.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var rm := ShaderMaterial.new()
	rm.shader = FX.round_shader()
	rm.set_shader_parameter("psize", Vector2(150, 150))
	rm.set_shader_parameter("rad", 22.0)
	_cover_img.material = rm
	cover.add_child(_cover_img)
	var eq := Control.new()
	eq.mouse_filter = Control.MOUSE_FILTER_IGNORE
	eq.set_anchors_preset(Control.PRESET_FULL_RECT)
	eq.draw.connect(func():
		for k in 4:
			var h: float = [8.0, 14.0, 6.0, 20.0][k]
			eq.draw_rect(Rect2(14.0 + float(k) * 8.0, 150.0 - 14.0 - h, 5.0, h), Color(1, 1, 1, 0.92)))
	cover.add_child(eq)
	_name = UI.label("", 15, FX.TX, "bold")
	_name.clip_text = true
	_name.text_overrun_behavior = TextServer.OVERRUN_TRIM_ELLIPSIS
	_name.custom_minimum_size = Vector2(150, 0)
	left.add_child(_name)
	_meta = UI.label("", 11, FX.MUT)
	left.add_child(_meta)
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 4)
	grid.add_theme_constant_override("v_separation", 4)
	grid.mouse_filter = Control.MOUSE_FILTER_PASS
	left.add_child(grid)
	for g in C.GRS:
		var chip := UI.card({"c1": Color(1, 1, 1, 0.04), "c2": Color(1, 1, 1, 0.04), "bcol": Color(1, 1, 1, 0.12), "bw": 1.0, "rad": 8.0}, 2, 1, 2, 2)
		chip.custom_minimum_size = Vector2(35, 31)
		var cv := UI.vbox(0)
		cv.alignment = BoxContainer.ALIGNMENT_CENTER
		var gl := UI.label(String(g), 13, C.grade_color(String(g)), "bolditalic", HORIZONTAL_ALIGNMENT_CENTER)
		var cl := UI.label("0", 9, FX.MUT, "medium", HORIZONTAL_ALIGNMENT_CENTER)
		cv.add_child(gl)
		cv.add_child(cl)
		chip.body.add_child(cv)
		grid.add_child(chip)
		_chips.append({"g": String(g), "panel": chip, "count": cl})
	# ---------------- kanan: header + panel + START
	var right := UI.vbox(6)
	right.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main.add_child(right)
	var head := UI.hbox(8)
	head.custom_minimum_size = Vector2(0, 34)
	head.add_child(UI.label("Set Up Game", 18, FX.TX, "bold"))
	head.add_child(UI.spacer(0, 0, true))
	var del := UI.btn("", 12, FX.s_pill(), Vector2(34, 34))
	del.set_icon(UI.icon("trash"), 14, Color(1, 1, 1, 0.8))
	del.pressed.connect(_on_delete)
	head.add_child(del)
	var xb := UI.btn("", 12, FX.s_pill(), Vector2(34, 34))
	xb.set_icon(UI.icon("close"), 13, Color.WHITE)
	xb.pressed.connect(func(): nav.emit("lib", {}))
	head.add_child(xb)
	right.add_child(head)
	var panel := UI.card(FX.s_panel(), 12, 10, 12, 10)
	panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	right.add_child(panel)
	var cols := UI.hbox(12)
	panel.body.add_child(cols)
	# kolom level
	var dc := UI.vbox(5)
	dc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	dc.size_flags_stretch_ratio = 1.0
	cols.add_child(dc)
	dc.add_child(UI.spaced("DIFFICULTY", 10, FX.MUT, 2))
	for i in 3:
		var row := _make_row(i)
		dc.add_child(row)
		_rows.append(row)
	# kolom pengaturan
	var sc := UI.vbox(4)
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.size_flags_stretch_ratio = 1.1
	cols.add_child(sc)
	var ah := UI.hbox(4)
	ah.add_child(UI.spaced("ACCURACY", 10, FX.MUT, 2))
	_acc_val = UI.label("", 12, FX.TX, "bold", HORIZONTAL_ALIGNMENT_RIGHT)
	_acc_val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ah.add_child(_acc_val)
	sc.add_child(ah)
	var ar := UI.hbox(6)
	for i in 3:
		var b := UI.btn(String(C.ACC_N[i]), 12, FX.s_opt(false), Vector2(0, 32), FX.TX)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func():
			Store.SET["acc"] = i
			Store.save_soon()
			_refresh_acc())
		_acc_btns.append(b)
		ar.add_child(b)
	sc.add_child(ar)
	sc.add_child(UI.spacer(0, 2))
	var sh := UI.hbox(4)
	sh.add_child(UI.spaced("DROP SPEED", 10, FX.MUT, 2))
	_spd_val = UI.label("", 12, FX.TX, "bold", HORIZONTAL_ALIGNMENT_RIGHT)
	_spd_val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sh.add_child(_spd_val)
	sc.add_child(sh)
	_spd_sl = _slider_row(sc, 0.6, 1.6, 0.1, 0.1, Color("#ff9f1c"), Color("#ff3d81"))
	_spd_sl.value_changed.connect(func(v: float):
		Store.SET["spd"] = snappedf(v, 0.1)
		Store.save_soon()
		_refresh_labels())
	sc.add_child(UI.spacer(0, 2))
	var yh := UI.hbox(4)
	yh.add_child(UI.spaced("SYNC", 10, FX.MUT, 2))
	_sync_val = UI.label("", 12, FX.TX, "bold", HORIZONTAL_ALIGNMENT_RIGHT)
	_sync_val.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	yh.add_child(_sync_val)
	sc.add_child(yh)
	_sync_sl = _slider_row(sc, -300.0, 300.0, 10.0, 10.0, Color("#38e6ff"), Color("#3a8bff"))
	_sync_sl.value_changed.connect(func(v: float):
		Store.sync_ms = int(v)
		Store.stats["sync"] = 1
		Store.save_soon()
		_refresh_labels())
	# START
	var srow := UI.hbox(0)
	srow.add_child(UI.spacer(0, 0, true))
	var st := FX.s_start()
	st["shine"] = true
	var start := UI.btn("", 17, st, Vector2(230, 46))
	var sb := start.make_body(0, 0, 0, 4)
	var sbox := UI.hbox(8)
	sbox.alignment = BoxContainer.ALIGNMENT_CENTER
	sbox.mouse_filter = Control.MOUSE_FILTER_PASS
	var pi := UI.icon_rect("play", 15, Color("#04152f"))
	pi.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	sbox.add_child(pi)
	var stl := UI.spaced("START", 18, Color("#04152f"), 4)
	stl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	sbox.add_child(stl)
	sb.add_child(sbox)
	start.pressed.connect(func(): nav.emit("start", {"diff": sel_diff}))
	srow.add_child(start)
	right.add_child(srow)


func _make_row(i: int) -> Control:
	var row := UI.btn("", 14, FX.s_row(false), Vector2(0, 50))
	row.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var body := row.make_body(18, 4, 38, 4)
	var v := UI.vbox(0)
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.mouse_filter = Control.MOUSE_FILTER_PASS
	var nm := UI.label(String(C.DIFF_N[i]), 15, FX.TX, "bold")
	var sub := UI.label("", 10, FX.MUT)
	v.add_child(nm)
	v.add_child(sub)
	body.add_child(v)
	var bar := UI.WPanel.new()
	bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bar.style({"c1": DIFF_COL[i], "c2": DIFF_COL[i], "rad": 3.0, "gcol": Color(DIFF_COL[i].r, DIFF_COL[i].g, DIFF_COL[i].b, 0.7), "gsz": 6.0})
	bar.anchor_left = 0.0
	bar.anchor_right = 0.0
	bar.anchor_top = 0.14
	bar.anchor_bottom = 0.86
	bar.offset_left = 6.0
	bar.offset_right = 11.0
	row.add_child(bar)
	var pips := Control.new()
	pips.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pips.anchor_left = 1.0
	pips.anchor_right = 1.0
	pips.anchor_top = 0.0
	pips.anchor_bottom = 1.0
	pips.offset_left = -30.0
	pips.offset_right = -10.0
	pips.draw.connect(func():
		var on: bool = pips.get_meta("on", false)
		var hs := [8.0, 13.0, 18.0]
		for k in 3:
			var col := Color(1, 1, 1, 0.18)
			if k <= i:
				col = DIFF_COL[i] if on else Color(1, 1, 1, 0.45)
			var h: float = hs[k]
			pips.draw_rect(Rect2(float(k) * 7.0, pips.size.y * 0.5 + 9.0 - h, 5.0, h), col))
	row.add_child(pips)
	row.set_meta("sub", sub)
	row.set_meta("pips", pips)
	row.pressed.connect(func(): _pick_diff(i))
	return row


func _slider_row(parent: Control, mn: float, mx: float, st: float, nudge: float, ca: Color, cb: Color) -> Control:
	var r := UI.hbox(6)
	var minus := UI.btn("-", 18, FX.s_pill(), Vector2(30, 30))
	var sl := UI.WSlider.new()
	sl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sl.setup(mn, mx, st, mn)
	sl.set_colors(ca, cb)
	var plus := UI.btn("+", 18, FX.s_pill(), Vector2(30, 30))
	minus.pressed.connect(func(): sl.nudge(-nudge))
	plus.pressed.connect(func(): sl.nudge(nudge))
	r.add_child(minus)
	r.add_child(sl)
	r.add_child(plus)
	parent.add_child(r)
	return sl


func on_enter(args: Dictionary = {}) -> void:
	song_id = String(args.get("id", song_id))
	_counts = args.get("counts", _counts)
	if args.has("diff"):
		sel_diff = int(args["diff"])
	var e := Store.find_song(song_id)
	if e.is_empty():
		nav.emit("lib", {})
		return
	_name.text = String(e["name"])
	var tex := Store.thumb_texture(song_id)
	_cover_img.texture = tex
	_cover_img.visible = tex != null
	_cover_note.visible = tex == null
	_spd_sl.set_value_silent(float(Store.SET["spd"]))
	_sync_sl.set_value_silent(float(Store.sync_ms))
	var gc := Store.grade_counts(song_id)
	for ch in _chips:
		var n := int(gc.get(ch["g"], 0))
		var col := C.grade_color(String(ch["g"]))
		var p = ch["panel"]
		(ch["count"] as Label).text = str(n)
		if n > 0:
			p.style({"c1": Color(col.r, col.g, col.b, 0.16), "c2": Color(col.r, col.g, col.b, 0.07), "bcol": Color(col.r, col.g, col.b, 0.85), "bw": 1.0, "rad": 8.0,
					"gcol": Color(col.r, col.g, col.b, 0.35), "gsz": 6.0})
			p.modulate.a = 1.0
		else:
			p.style({"c1": Color(1, 1, 1, 0.04), "c2": Color(1, 1, 1, 0.04), "bcol": Color(1, 1, 1, 0.12), "bw": 1.0, "rad": 8.0})
			p.modulate.a = 0.5
	_refresh_diff()
	_refresh_acc()
	_refresh_labels()
	fade_in(0.25)


func _pick_diff(i: int) -> void:
	sel_diff = i
	_refresh_diff()


func _refresh_diff() -> void:
	for i in 3:
		var row = _rows[i]
		var n := 0
		var h := 0
		if _counts.size() > i and _counts[i] is Dictionary:
			n = int(_counts[i].get("n", 0))
			h = int(_counts[i].get("h", 0))
		(row.get_meta("sub") as Label).text = "%d notes · %d holds · %s" % [n, h, C.DIFF_SUB[i]]
		var on := i == sel_diff
		row.style(FX.s_row(on, DIFF_COL[i]))
		var pips: Control = row.get_meta("pips")
		pips.set_meta("on", on)
		pips.queue_redraw()
	var bs := Store.best_get(song_id, sel_diff)
	var e := Store.find_song(song_id)
	var dur := C.fmt_dur(float(e.get("dur", 0.0)))
	_meta.text = "%s · Best %s" % [dur, C.fmt_int(bs) if bs > 0 else "—"]


func _refresh_acc() -> void:
	var cur := int(Store.SET["acc"])
	for i in 3:
		var b = _acc_btns[i]
		if i == cur:
			b.style(ACC_ON)
			b.label.add_theme_color_override("font_color", Color("#ffe9a6"))
		else:
			b.style(FX.s_opt(false))
			b.label.add_theme_color_override("font_color", FX.TX)
	_acc_val.text = "Perfect ±%d ms" % roundi(70.0 * float(C.ACC_K[cur]))


func _refresh_labels() -> void:
	_spd_val.text = "%.1fx" % float(Store.SET["spd"])
	_sync_val.text = "%d ms" % Store.sync_ms


func _on_delete() -> void:
	var e := Store.find_song(song_id)
	if e.is_empty():
		return
	var dlg := ConfirmationDialog.new()
	dlg.title = "Delete song"
	dlg.dialog_text = "Delete \"%s\" from this device? Its scores and cache are removed too." % String(e["name"])
	dlg.ok_button_text = "Delete"
	dlg.cancel_button_text = "Cancel"
	add_child(dlg)
	dlg.confirmed.connect(func():
		dlg.queue_free()
		Store.remove_song(song_id)
		toast_req.emit("Song deleted")
		nav.emit("lib", {}))
	dlg.canceled.connect(func(): dlg.queue_free())
	dlg.popup_centered(Vector2i(320, 130))


func on_back() -> void:
	nav.emit("lib", {})
