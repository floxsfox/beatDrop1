extends "res://scripts/w_panel.gd"
## Tombol bergaya (panel shader + label + ikon). Tidak menelan sentuhan: bila jari bergeser
## lebih dari ambang, ketukan dibatalkan dan gerakan diteruskan ke area scroll di belakangnya.

signal pressed

var label: Label
var icon_rect: TextureRect
var enabled := true
var tap_threshold := 12.0

var _down := false
var _p0 := Vector2.ZERO
var _t0 := 0
var _tw: Tween = null


func _init() -> void:
	super()
	focus_mode = Control.FOCUS_NONE


## Tambah label di tengah. kind: "bold"/"medium"/...
func set_text(text: String, size: int = 14, color: Color = Color("#f5f2ff"), kind: String = "bold", spacing: int = 0) -> void:
	if label == null:
		label = Label.new()
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		label.set_anchors_preset(Control.PRESET_FULL_RECT)
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		add_child(label)
	label.text = text
	var f := FontVariation.new()
	f.base_font = FX.font(kind)
	f.spacing_glyph = spacing
	label.add_theme_font_override("font", f)
	label.add_theme_font_size_override("font_size", size)
	label.add_theme_color_override("font_color", color)


func set_icon(tex: Texture2D, px: int, tint: Color = Color.WHITE, left: bool = false) -> void:
	if icon_rect == null:
		icon_rect = TextureRect.new()
		icon_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
		icon_rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icon_rect.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		add_child(icon_rect)
	icon_rect.texture = tex
	icon_rect.modulate = tint
	icon_rect.custom_minimum_size = Vector2(px, px)
	icon_rect.set_anchors_preset(Control.PRESET_CENTER_LEFT if left else Control.PRESET_CENTER)
	icon_rect.offset_left = 14.0 if left else -px / 2.0
	icon_rect.offset_right = icon_rect.offset_left + px
	icon_rect.offset_top = -px / 2.0
	icon_rect.offset_bottom = px / 2.0


func set_enabled(v: bool) -> void:
	enabled = v
	modulate.a = 1.0 if v else 0.45


func _anim_scale(to: float) -> void:
	if _tw != null:
		_tw.kill()
	_tw = create_tween()
	_tw.tween_property(self, "scale", Vector2(to, to), 0.08)


func _gui_input(e: InputEvent) -> void:
	if not enabled:
		return
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		if e.pressed:
			_down = true
			_p0 = e.global_position
			_t0 = Time.get_ticks_msec()
			_anim_scale(0.96)
		elif _down:
			_down = false
			_anim_scale(1.0)
			var moved: float = e.global_position.distance_to(_p0)
			if moved < tap_threshold and Time.get_ticks_msec() - _t0 < 700 and Rect2(Vector2.ZERO, size).has_point(e.position):
				Sfx.click()
				pressed.emit()
	elif e is InputEventMouseMotion and _down:
		if e.global_position.distance_to(_p0) > tap_threshold:
			_down = false
			_anim_scale(1.0)
