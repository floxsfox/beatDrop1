extends RefCounted
## Konstanta dan tabel statis BeatDrop (port dari index.html).

const GAME_H := 400.0          # tinggi "dunia" game (satuan virtual). Layout asli dirancang untuk ~400px.
const FPS_CAP := 60

const LABELS := ["D", "F", "SPC", "J", "K"]
const DIFF_N := ["Easy", "Normal", "Hard"]
const DIFF_SUB := ["Chill", "Fun", "Extreme"]
const GRS := ["F", "C", "B", "B+", "A", "A+", "S", "S+"]
const ACC_K := [1.2, 1.0, 0.75]
const ACC_N := ["Loose", "Normal", "Strict"]
const TIER_N := ["Easy", "Normal", "Hard", "Impossible"]
const TIER_C := ["#2ee6a6", "#3aa0ff", "#ff9f1c", "#ff3d81"]

const DEFAULT_COLORS := ["#ff3d81", "#ff9f1c", "#2ee6a6", "#3aa0ff", "#b36bff"]
const PALS := {
	"Neon": ["#ff3d81", "#ff9f1c", "#2ee6a6", "#3aa0ff", "#b36bff"],
	"Pastel": ["#ff8fb3", "#ffd166", "#8ce8c0", "#8ecae6", "#c8b6ff"],
	"Sunset": ["#ff595e", "#ff924c", "#ffca3a", "#8ac926", "#1982c4"],
	"Mono": ["#f5f2ff", "#c9c4e8", "#9e98cc", "#6f6a94", "#4a4668"],
}

# Tinggi render game (piksel) untuk tiap pilihan "Game resolution". Default 50 -> HD 720p.
const RES_H := {40: 540, 50: 720, 75: 900, 100: 1080}
const RES_NAME := {40: "Saver 540p", 50: "HD 720p", 75: "Sharp 900p", 100: "Full HD"}

const HOLE_N := ["Pill", "Circle", "Box", "Square 1:1"]
const NSHAPE_OPTS := [[0, "Pill"], [2, "Box"], [1, "Square 1:1"]]

# Waktu tempuh not (detik) dari atas layar ke garis tombol, untuk generator V2/V3 pada speed 1.0x.
const WAKTU_PERJALANAN_NOT := 2.0

# Tabel kesulitan generator V1.
const DF := [
	{"n": "Easy", "k": 2.7, "ga": 0.55, "gl": 0.7, "ms": 1, "busy": 1, "pz": 0.6, "hm": 0.85, "ap": 2.4, "mp": [1, 1, 2, 3, 3], "cc": 99.0, "brun": 24, "bgap": 0.9},
	{"n": "Normal", "k": 2.55, "ga": 0.5, "gl": 0.6, "ms": 2, "busy": 1, "pz": 0.4, "hm": 0.9, "ap": 2.15, "mp": [0, 1, 2, 3, 4], "cc": 1.5, "brun": 12, "bgap": 0.9},
	{"n": "Hard", "k": 1.8, "ga": 0.2, "gl": 0.3, "ms": 3, "busy": 0, "pz": 0.0, "hm": 0.6, "ap": 1.55, "mp": [0, 1, 2, 3, 4], "cc": 0.0, "brun": 99, "bgap": 0.9},
]

# Generator V2 (bass scan).
const V2D := [
	{"cdK": 1.8, "cdMin": 0.45, "thAdd": 0.35, "lanes": [1, 2, 3], "chord": 0},
	{"cdK": 1.0, "cdMin": 0.15, "thAdd": 0.0, "lanes": [0, 1, 2, 3, 4], "chord": 0},
	{"cdK": 0.8, "cdMin": 0.15, "thAdd": -0.2, "lanes": [0, 1, 2, 3, 4], "chord": 1},
]

# Generator V3 (melodi / pitch).
const V3D := [
	{"lanes": [1, 2, 3], "min": 0.30, "gap": 0.40, "hold": 0.90, "trim": 0.20},
	{"lanes": [0, 1, 2, 3, 4], "min": 0.16, "gap": 0.20, "hold": 0.60, "trim": 0.14},
	{"lanes": [0, 1, 2, 3, 4], "min": 0.09, "gap": 0.11, "hold": 0.45, "trim": 0.10},
]

# 54 prestasi: [id, nama, deskripsi, tier, kunci_statistik, ambang]
# kunci khusus: "g:S" (jumlah nilai), "fc:0", "cl:0", "diffs" (jumlah level), "racc" (akurasi satu permainan).
const ACHV := [
	["main1", "First Steps", "Play 1 song", 0, "plays", 1],
	["main5", "Getting Serious", "Play 5 songs", 0, "plays", 5],
	["main10", "Regular", "Play 10 songs", 1, "plays", 10],
	["main25", "Marathon", "Play 25 songs", 2, "plays", 25],
	["main50", "Stage Legend", "Play 50 songs", 3, "plays", 50],
	["hit100", "Warm-Up", "Hit 100 notes", 0, "hits", 100],
	["hit500", "Nimble Fingers", "Hit 500 notes", 0, "hits", 500],
	["hit1k", "Combo Walker", "Hit 1,000 notes", 1, "hits", 1000],
	["hit5k", "Tapping Machine", "Hit 5,000 notes", 1, "hits", 5000],
	["hit10k", "Finger Storm", "Hit 10,000 notes", 2, "hits", 10000],
	["hit25k", "Rhythm God", "Hit 25,000 notes", 3, "hits", 25000],
	["pf50", "Accurate", "50 Perfects", 0, "perfects", 50],
	["pf300", "Precise", "300 Perfects", 1, "perfects", 300],
	["pf1k", "Flawless", "1,000 Perfects", 2, "perfects", 1000],
	["pf5k", "Spotless", "5,000 Perfects", 3, "perfects", 5000],
	["cb25", "25 Combo", "Reach 25 combo", 0, "bestCombo", 25],
	["cb50", "50 Combo", "Reach 50 combo", 0, "bestCombo", 50],
	["cb100", "100 Combo", "Reach 100 combo", 1, "bestCombo", 100],
	["cb200", "200 Combo", "Reach 200 combo", 2, "bestCombo", 200],
	["cb300", "300 Combo", "Reach 300 combo", 3, "bestCombo", 300],
	["s1", "S Star", "Earn 1 S grade", 1, "g:S", 1],
	["s3", "S Collector", "Earn 3 S grades", 2, "g:S", 3],
	["s5", "S Hunter", "Earn 5 S grades", 2, "g:S", 5],
	["s10", "S Master", "Earn 10 S grades", 3, "g:S", 10],
	["sp1", "On Fire!", "Earn 1 S+ grade", 2, "g:S+", 1],
	["sp3", "Eternal Flame", "Earn 3 S+ grades", 3, "g:S+", 3],
	["fc0", "Full Combo (Easy)", "Full combo on Easy", 0, "fc:0", 1],
	["fc1", "Full Combo (Normal)", "Full combo on Normal", 1, "fc:1", 1],
	["fc2", "Full Combo (Hard)", "Full combo on Hard", 2, "fc:2", 1],
	["cl0", "Cleared (Easy)", "Finish an Easy song", 0, "cl:0", 1],
	["cl1", "Cleared (Normal)", "Finish a Normal song", 0, "cl:1", 1],
	["cl2", "Cleared (Hard)", "Finish a Hard song", 1, "cl:2", 1],
	["lib1", "Collector", "Save 1 song", 0, "songs", 1],
	["lib3", "Librarian", "Save 3 songs", 1, "songs", 3],
	["lib5", "Archivist", "Save 5 songs", 2, "songs", 5],
	["col1", "Stylist", "Change beat colors", 0, "colors", 1],
	["pv1", "Listener", "Play a song preview", 0, "previews", 1],
	["fail1", "Failure Is Fine", "Run out of HP once", 0, "fails", 1],
	["miss100", "Note Victim", "100 Misses total", 0, "misses", 100],
	["pause1", "Take A Break", "Pause once", 0, "pauses", 1],
	["sync1", "Calibrator", "Adjust sync", 0, "sync", 1],
	["night1", "Night Owl", "Play at 10PM-4AM", 0, "night", 1],
	["hold50", "Hold It!", "Clear 50 hold notes", 1, "holds", 50],
	["gr500", "So Good", "500 Greats", 0, "greats", 500],
	["gr2k", "Amazing", "2,000 Greats", 1, "greats", 2000],
	["sc10k", "10K Score", "Score 10,000 in one run", 1, "maxScore", 10000],
	["sc50k", "50K Score", "Score 50,000 in one run", 2, "maxScore", 50000],
	["sc100k", "100K Score", "Score 100,000 in one run", 3, "maxScore", 100000],
	["acc90", "90% Accuracy", "90% accuracy in one run", 1, "racc", 0.9],
	["acc95", "95% Accuracy", "95% accuracy in one run", 2, "racc", 0.95],
	["acc98", "98% Accuracy", "98% accuracy in one run", 3, "racc", 0.98],
	["acc100", "No Mistakes", "100% accuracy in one run", 3, "racc", 1.0],
	["lowhp", "Close Call!", "Finish with HP under 20%", 1, "lowhp", 1],
	["alldiff", "Explorer", "Play all difficulties", 1, "diffs", 3],
]


static func grade_color(g: String) -> Color:
	match g.substr(0, 1):
		"F":
			return Color("#8d93a6")
		"C":
			return Color("#ffd94a")
		"B":
			return Color("#2ee6a6")
		"A":
			return Color("#ffb700")
		_:
			return Color("#ff2d55")


static func fmt_int(v: int) -> String:
	var s := str(absi(v))
	var out := ""
	var n := s.length()
	for i in n:
		out += s[i]
		var rem := n - 1 - i
		if rem > 0 and rem % 3 == 0:
			out += ","
	return ("-" + out) if v < 0 else out


static func fmt_dur(d: float) -> String:
	var m := int(d) / 60
	var s := int(d) % 60
	return "%d:%02d" % [m, s]


static func hsl_to_color(h: float, s: float, l: float) -> Color:
	var hh := fposmod(h, 360.0) / 360.0
	var ss := s / 100.0
	var ll := l / 100.0
	var q := ll * (1.0 + ss) if ll < 0.5 else ll + ss - ll * ss
	var p := 2.0 * ll - q
	return Color(_hue2rgb(p, q, hh + 1.0 / 3.0), _hue2rgb(p, q, hh), _hue2rgb(p, q, hh - 1.0 / 3.0), 1.0)


static func _hue2rgb(p: float, q: float, t: float) -> float:
	var tt := fposmod(t, 1.0)
	if tt < 1.0 / 6.0:
		return p + (q - p) * 6.0 * tt
	if tt < 0.5:
		return q
	if tt < 2.0 / 3.0:
		return p + (q - p) * (2.0 / 3.0 - tt) * 6.0
	return p


static func color_to_hsl(c: Color) -> Dictionary:
	var r := c.r
	var g := c.g
	var b := c.b
	var mx := maxf(r, maxf(g, b))
	var mn := minf(r, minf(g, b))
	var hh := 0.0
	var ss := 0.0
	var ll := (mx + mn) / 2.0
	if mx != mn:
		var d := mx - mn
		ss = d / (2.0 - mx - mn) if ll > 0.5 else d / (mx + mn)
		if mx == r:
			hh = (g - b) / d + (6.0 if g < b else 0.0)
		elif mx == g:
			hh = (b - r) / d + 2.0
		else:
			hh = (r - g) / d + 4.0
		hh *= 60.0
	return {"h": roundi(hh) % 360, "s": roundi(ss * 100.0), "l": clampi(roundi(ll * 100.0), 5, 95)}
