extends RefCounted
## Analisis audio + generator not (port V1 / V2 / V3 dari index.html).
##
## Dibuat agar ringan di ponsel:
##  - Audio didekode NATIF oleh Godot (AudioStreamPlayback.mix_audio), lalu di-downsample 4x (~11 kHz).
##  - FFT 2 frame sekaligus (trik real-FFT), dibagi ke beberapa thread.
##  - Hasil analisis di-cache ke user://beatdrop/cache sehingga lagu yang sama tidak dianalisis ulang.
## Semua berjalan di thread latar; UI hanya membaca progress().

const C = preload("res://scripts/consts.gd")

# --- parameter analisis V1 (resolusi waktu sama dengan versi web: 1024/512 @44.1k == 256/128 @11k)
const N1 := 256
const HOP1 := 128
const DECIM := 4
# --- V2
const V2_HOP := 32
const V2_WIN := 4
const V2_LAG := 4
const V2_AHEAD := 35
# --- V3 (dihitung pada sr/2 ~ 5.5 kHz)
const V3_N := 1024
const V3_HOP := 128
const V3_BPS := 4
const V3_M0 := 43
const V3_M1 := 86
const V3_HM := 10
const V3_FMAX := 2700.0

const STAGE_TEXT := ["", "Decoding audio...", "Finding beats...", "Scanning bass...",
		"Reading pitch...", "Tracking melody...", "Building notes..."]

var stage: int = 0
var stage_done: int = 0
var stage_total: int = 1
var finished := false
var result: Array = []          # [easy[], normal[], hard[]] -> tiap not {t,l,dur}
var used_gen: int = 1
var cancel := false

var _thread: Thread = null
var _mtx := Mutex.new()
var _pcm: Dictionary = {}


func start(stream: AudioStream, song_id: String, gen: int, params: Dictionary) -> void:
	_thread = Thread.new()
	_thread.start(_run.bind(stream, song_id, gen, params))


func join() -> void:
	if _thread != null and _thread.is_started():
		_thread.wait_to_finish()


func progress() -> float:
	return clampf(float(stage_done) / float(maxi(1, stage_total)), 0.0, 1.0)


func stage_text() -> String:
	return STAGE_TEXT[clampi(stage, 0, STAGE_TEXT.size() - 1)]


func _set_stage(s: int, total: int) -> void:
	_mtx.lock()
	stage = s
	stage_total = maxi(1, total)
	stage_done = 0
	_mtx.unlock()


func _tick(n: int) -> void:
	_mtx.lock()
	stage_done += n
	_mtx.unlock()


# ------------------------------------------------------------------ alur utama (thread)

func _run(stream: AudioStream, id: String, gen: int, params: Dictionary) -> void:
	var dur := stream.get_length()
	var notes: Array = []
	var g := gen
	if g == 3:
		notes = _run_v3(stream, id, dur, params)
		if _count(notes) < 8:
			g = 1
	elif g == 2:
		notes = _run_v2(stream, id, dur, params)
		if _count(notes) < 8:
			g = 1
	if g == 1:
		notes = _run_v1(stream, id, dur)
	_set_stage(6, 1)
	result = notes
	used_gen = g
	finished = true


func _count(notes: Array) -> int:
	var n := 0
	for a in notes:
		n += a.size()
	return n


func _get_pcm(stream: AudioStream) -> Dictionary:
	if _pcm.is_empty():
		_pcm = _decode(stream)
	return _pcm


## Dekode audio -> mono float 32 pada sample-rate (mix_rate / 4).
func _decode(stream: AudioStream) -> Dictionary:
	var pb: AudioStreamPlayback = stream.instantiate_playback()
	var mix_rate: float = AudioServer.get_mix_rate()
	var dur := stream.get_length()
	var total_frames := int(dur * mix_rate) + 4096
	_set_stage(1, total_frames)
	var out := PackedFloat32Array()
	out.resize(total_frames / DECIM + 16)
	var oi := 0
	var acc := 0.0
	var cnt := 0
	var done := 0
	var chunk := 8192
	pb.start(0.0)
	while done < total_frames and not cancel:
		var buf: PackedVector2Array = pb.mix_audio(1.0, chunk)
		var n := buf.size()
		if n == 0:
			break
		var i := 0
		# lengkapi grup yang tersisa dari chunk sebelumnya
		while cnt > 0 and i < n:
			var v: Vector2 = buf[i]
			acc += v.x + v.y
			cnt += 1
			i += 1
			if cnt == DECIM:
				if oi < out.size():
					out[oi] = acc / (2.0 * DECIM)
				oi += 1
				acc = 0.0
				cnt = 0
		# jalur cepat: 4 frame sekaligus
		var lim := n - (DECIM - 1)
		while i < lim:
			var a: Vector2 = buf[i]
			var b: Vector2 = buf[i + 1]
			var c: Vector2 = buf[i + 2]
			var d: Vector2 = buf[i + 3]
			if oi < out.size():
				out[oi] = (a.x + a.y + b.x + b.y + c.x + c.y + d.x + d.y) * 0.125
			oi += 1
			i += DECIM
		# sisa (<4 frame) dibawa ke chunk berikutnya
		while i < n:
			var v2: Vector2 = buf[i]
			acc += v2.x + v2.y
			cnt += 1
			i += 1
		done += n
		_tick(n)
		if not pb.is_playing() and n < chunk:
			break
	out.resize(mini(oi, out.size()))
	return {"x": out, "sr": mix_rate / float(DECIM)}


# ------------------------------------------------------------------ util FFT / paralel

func _fft_tables(n: int) -> Dictionary:
	var lg := int(round(log(float(n)) / log(2.0)))
	var rev := PackedInt32Array()
	rev.resize(n)
	for i in n:
		var r := 0
		for b in lg:
			r |= ((i >> b) & 1) << (lg - 1 - b)
		rev[i] = r
	var half := n >> 1
	var cs := PackedFloat32Array()
	var sn := PackedFloat32Array()
	cs.resize(half)
	sn.resize(half)
	for i in half:
		cs[i] = cos(TAU * float(i) / float(n))
		sn[i] = -sin(TAU * float(i) / float(n))
	var win := PackedFloat32Array()
	win.resize(n)
	for i in n:
		win[i] = 0.5 - 0.5 * cos(TAU * float(i) / float(n))
	return {"rev": rev, "cs": cs, "sn": sn, "win": win}


## FFT radix-2 in-place; input SUDAH dalam urutan bit-reversed.
func _fft_br(re: PackedFloat32Array, im: PackedFloat32Array, n: int, cs: PackedFloat32Array, sn: PackedFloat32Array) -> void:
	var s := 2
	while s <= n:
		var h := s >> 1
		var st := n / s
		for j in h:
			var wr := cs[j * st]
			var wi := sn[j * st]
			for a in range(j, n, s):
				var b := a + h
				var xr := re[b]
				var xi := im[b]
				var tre := xr * wr - xi * wi
				var tim := xr * wi + xi * wr
				var ar := re[a]
				var ai := im[a]
				re[b] = ar - tre
				im[b] = ai - tim
				re[a] = ar + tre
				im[a] = ai + tim
		s <<= 1


## Jalankan job(i0, i1) pada beberapa thread; hasil dikembalikan berurutan.
func _par(job: Callable, total: int) -> Array:
	var nt := clampi(OS.get_processor_count() - 1, 1, 4)
	var per := int(ceil(float(total) / float(nt)))
	var threads: Array = []
	for t in nt:
		var i0 := t * per
		var i1 := mini(total, i0 + per)
		if i0 >= i1:
			break
		var th := Thread.new()
		th.start(func(): return job.call(i0, i1))
		threads.append(th)
	var res: Array = []
	for th in threads:
		res.append(th.wait_to_finish())
	return res


# ------------------------------------------------------------------ V1

func _run_v1(stream: AudioStream, id: String, dur: float) -> Array:
	var cp := Store.cache_path(id, "v1")
	var A = Store.cache_read(cp)
	if A == null:
		var pcm := _get_pcm(stream)
		A = _analyze_v1(pcm["x"], float(pcm["sr"]))
		Store.cache_write(cp, A)
	_set_stage(6, 1)
	var out: Array = []
	for di in 3:
		out.append(_gen_v1(A, di, dur))
	return out


func _job_v1(p0: int, p1: int, x: PackedFloat32Array, nF: int, tb: Dictionary, ed: PackedInt32Array, scale: float) -> Array:
	var rev: PackedInt32Array = tb["rev"]
	var cs: PackedFloat32Array = tb["cs"]
	var sn: PackedFloat32Array = tb["sn"]
	var win: PackedFloat32Array = tb["win"]
	var N := N1
	var re := PackedFloat32Array()
	var im := PackedFloat32Array()
	re.resize(N)
	im.resize(N)
	var inv: Array = []
	for b in 5:
		inv.append(1.0 / sqrt(float(ed[b + 1] - ed[b])))
	var out: Array = []
	for b in 5:
		var arr := PackedFloat32Array()
		arr.resize((p1 - p0) * 2)
		out.append(arr)
	for p in range(p0, p1):
		var fa := p * 2
		var fb := fa + 1
		var oa := fa * HOP1
		var ob := fb * HOP1
		var hasb := fb < nF
		for i in N:
			var r := rev[i]
			re[r] = x[oa + i] * win[i]
			im[r] = (x[ob + i] * win[i]) if hasb else 0.0
		_fft_br(re, im, N, cs, sn)
		var oi := (p - p0) * 2
		for b in 5:
			var sa := 0.0
			var sb := 0.0
			for k in range(ed[b], ed[b + 1]):
				var rk := re[k]
				var rn := re[N - k]
				var ik := im[k]
				var inn := im[N - k]
				var u := rk + rn
				var w := ik - inn
				var u2 := ik + inn
				var w2 := rk - rn
				sa += sqrt(u * u + w * w)
				sb += sqrt(u2 * u2 + w2 * w2)
			var arr: PackedFloat32Array = out[b]
			var f: float = scale * 0.5 * float(inv[b])
			arr[oi] = log(1.0 + sa * f)
			arr[oi + 1] = log(1.0 + sb * f)
		if (p & 31) == 31:
			_tick(32)
	return out


func _analyze_v1(x: PackedFloat32Array, sr: float) -> Dictionary:
	var nF := int((x.size() - N1) / HOP1)
	if nF < 50:
		return {"E": [], "F": [], "nF": 0, "sr": sr, "grid": {}}
	var tb := _fft_tables(N1)
	var edges := [40.0, 150.0, 400.0, 1200.0, 3500.0, 11000.0]
	var ed := PackedInt32Array()
	ed.resize(6)
	for i in 6:
		ed[i] = maxi(1, roundi(float(edges[i]) * float(N1) / sr))
	for i in range(1, 6):
		if ed[i] <= ed[i - 1]:
			ed[i] = ed[i - 1] + 1
	ed[5] = mini(ed[5], N1 >> 1)
	var pairs := (nF + 1) / 2
	_set_stage(2, pairs)
	var scale := 1024.0 / float(N1)
	var job := _job_v1.bind(x, nF, tb, ed, scale)
	var parts := _par(job, pairs)
	var E: Array = []
	var F: Array = []
	for b in 5:
		var e := PackedFloat32Array()
		for part in parts:
			e.append_array(part[b])
		e.resize(nF)
		E.append(e)
		var f := PackedFloat32Array()
		f.resize(nF)
		for i in range(1, nF):
			f[i] = maxf(0.0, e[i] - e[i - 1])
		F.append(f)
	var grid := _detect_grid(F, nF, sr)
	return {"E": E, "F": F, "nF": nF, "sr": sr, "grid": grid}


func _detect_grid(F: Array, nF: int, sr: float) -> Dictionary:
	var step := float(HOP1) / sr
	if nF < 200:
		return {}
	var flux := PackedFloat32Array()
	flux.resize(nF)
	for b in 5:
		var band: PackedFloat32Array = F[b]
		var mean := 0.0
		for i in range(1, nF):
			mean += band[i]
		mean /= maxf(1.0, float(nF - 1))
		if mean < 1e-8:
			continue
		for i in range(1, nF):
			flux[i] += minf(5.0, band[i] / mean) / 5.0
	var avg := 0.0
	for i in range(1, nF):
		avg += flux[i]
	avg /= maxf(1.0, float(nF - 1))
	for i in range(1, nF):
		flux[i] -= avg
	var min_lag := maxi(2, roundi((60.0 / 180.0) / step))
	var max_lag := mini(nF / 3, roundi((60.0 / 55.0) / step))
	var best_lag := 0
	var best_score := -1.0
	for lag in range(min_lag, max_lag + 1):
		var dot := 0.0
		var aa := 0.0
		var bb := 0.0
		for i in range(lag, nF):
			var xx := flux[i]
			var yy := flux[i - lag]
			dot += xx * yy
			aa += xx * xx
			bb += yy * yy
		var score := dot / sqrt(maxf(1e-12, aa * bb))
		var adjusted := score * (1.0 - float(lag - min_lag) / float(max_lag - min_lag + 1) * 0.025)
		if adjusted > best_score:
			best_score = adjusted
			best_lag = lag
	if best_lag == 0 or best_score < 0.045:
		return {}
	var best_phase := 0
	var best_phase_score := -INF
	for phase in best_lag:
		var sum := 0.0
		var count := 0
		var center := phase
		while center < nF:
			var local := -INF
			for dd in range(-2, 3):
				var i := center + dd
				if i >= 1 and i < nF:
					local = maxf(local, flux[i])
			if local > -INF:
				sum += local
				count += 1
			center += best_lag
		var sc := (sum / float(count)) if count > 0 else -INF
		if sc > best_phase_score:
			best_phase_score = sc
			best_phase = phase
	return {"period": float(best_lag) * step, "phase": (float(best_phase * HOP1) + float(N1) / 2.0) / sr, "confidence": best_score}


func _align_onset(t: float, grid: Dictionary) -> float:
	if grid.is_empty() or float(grid["confidence"]) < 0.10:
		return t
	var sub := float(grid["period"]) / 4.0
	if not (sub > 0.0):
		return t
	var snap_t := float(grid["phase"]) + roundf((t - float(grid["phase"])) / sub) * sub
	return snap_t if absf(snap_t - t) <= 0.038 else t


static func _cmp_ts(a: Dictionary, b: Dictionary) -> bool:
	if a["t"] != b["t"]:
		return a["t"] < b["t"]
	return a["s"] > b["s"]


func _gen_v1(A: Dictionary, di: int, dur: float) -> Array:
	var p: Dictionary = C.DF[di]
	var nF := int(A["nF"])
	if nF < 50:
		return []
	var E: Array = A["E"]
	var F: Array = A["F"]
	var sr := float(A["sr"])
	var grid: Dictionary = A["grid"]
	var mp: Array = p["mp"]
	var k := float(p["k"])
	var hm := float(p["hm"])
	var ws := 43
	var cand: Array = []
	for b in 5:
		var f: PackedFloat32Array = F[b]
		var eb: PackedFloat32Array = E[b]
		var pre := PackedFloat64Array()
		pre.resize(nF + 1)
		for i in nF:
			pre[i + 1] = pre[i] + f[i]
		for i in range(2, nF - 2):
			var a := maxi(0, i - ws)
			var z := mini(nF, i + ws + 1)
			var th := (pre[z] - pre[a]) / float(z - a) * k + 0.12
			if f[i] > th and f[i] >= f[i - 1] and f[i] > f[i + 1]:
				var pk := maxf(eb[i], eb[i + 1])
				var j := i + 1
				var g := 0
				while j < nF and j - i < 220:
					if eb[j] >= pk - 0.45:
						g = 0
					else:
						g += 1
						if g > 3:
							break
					j += 1
				var j0 := i
				while j0 > 0 and i - j0 < 3 and f[j0 - 1] > f[i] * 0.3:
					j0 -= 1
				var dn := float(j - g - i) * float(HOP1) / sr
				var raw_t := (float(j0 * HOP1) + float(N1) / 2.0) / sr
				var tt := _align_onset(raw_t, grid)
				var dd := 0.0
				if dn >= hm:
					dd = minf(dn, 2.5) - 0.05
				cand.append({"t": tt, "l": int(mp[b]), "s": f[i] - th, "d": dd})
	cand.sort_custom(_cmp_ts)
	var out: Array = []
	var last := [-9.0, -9.0, -9.0, -9.0, -9.0]
	var ct := -9.0
	var cn := 0
	var ch := 0
	var bz := 0.0
	var last_chord := -9.0
	var consec := 0
	var last_acc := -9.0
	var busy := int(p["busy"]) == 1
	var ga := float(p["ga"])
	var gl := float(p["gl"])
	var ms := int(p["ms"])
	var pz := float(p["pz"])
	var cc := float(p["cc"])
	var brun := int(p["brun"])
	var bgap := float(p["bgap"])
	for c in cand:
		var t: float = c["t"]
		var l: int = c["l"]
		var d: float = c["d"]
		if t < 1.2 or t > dur - 0.85 or t + d > dur - 0.18:
			continue
		if busy and t < bz:
			continue
		var nc := t - ct >= 0.05
		if nc and t - ct < ga:
			continue
		if (not nc) and (cn >= ms or (busy and (ch == 1 or d > 0.0))):
			continue
		if t < float(last[l]) + gl:
			continue
		if (not nc) and cc > 0.0 and t - last_chord < cc:
			continue
		var gap_b := t - last_acc
		if gap_b >= bgap:
			consec = 0
		else:
			consec += 1
			if consec > brun and gap_b < bgap:
				continue
		if nc:
			ct = t
			cn = 0
			ch = 0
		else:
			last_chord = t
		cn += 1
		if d > 0.0:
			ch = 1
			bz = t + d + pz
		last[l] = t + d
		last_acc = t
		out.append({"t": t, "l": l, "dur": d})
	return out


# ------------------------------------------------------------------ V2 (scan bass)

func _run_v2(stream: AudioStream, id: String, dur: float, params: Dictionary) -> Array:
	var cp := Store.cache_path(id, "v2")
	var S = Store.cache_read(cp)
	if S == null:
		var pcm := _get_pcm(stream)
		S = _scan_v2(pcm["x"], float(pcm["sr"]))
		Store.cache_write(cp, S)
	_set_stage(6, 1)
	var out: Array = []
	for di in 3:
		out.append(_gen_v2(S, di, dur, params))
	return out


func _biquad(fc: float, sr: float, hp: bool) -> Array:
	var w := TAU * fc / sr
	var c := cos(w)
	var al := sin(w) / sqrt(2.0)
	var a0 := 1.0 + al
	var b0 := ((1.0 + c) if hp else (1.0 - c)) / 2.0 / a0
	var b1 := (-(1.0 + c) if hp else (1.0 - c)) / a0
	return [b0, b1, b0, -2.0 * c / a0, (1.0 - al) / a0]


func _scan_v2(x: PackedFloat32Array, sr: float) -> Dictionary:
	var nb := x.size() / V2_HOP
	_set_stage(3, nb / 4096 + 1)
	var pc := _biquad(140.0, sr, false)
	var hc := _biquad(2500.0, sr, true)
	var p0 := float(pc[0])
	var p1 := float(pc[1])
	var p2 := float(pc[2])
	var p3 := float(pc[3])
	var p4 := float(pc[4])
	var h0 := float(hc[0])
	var h1 := float(hc[1])
	var h2 := float(hc[2])
	var h3 := float(hc[3])
	var h4 := float(hc[4])
	var za1 := 0.0
	var za2 := 0.0
	var zb1 := 0.0
	var zb2 := 0.0
	var zh1 := 0.0
	var zh2 := 0.0
	var eb := PackedFloat32Array()
	var eh := PackedFloat32Array()
	eb.resize(nb)
	eh.resize(nb)
	for k in nb:
		var sb := 0.0
		var sh := 0.0
		var s0 := k * V2_HOP
		for s in range(s0, s0 + V2_HOP):
			var xv := x[s]
			var y := p0 * xv + za1
			za1 = p1 * xv - p3 * y + za2
			za2 = p2 * xv - p4 * y
			var yb := p0 * y + zb1
			zb1 = p1 * y - p3 * yb + zb2
			zb2 = p2 * y - p4 * yb
			var yh := h0 * xv + zh1
			zh1 = h1 * xv - h3 * yh + zh2
			zh2 = h2 * xv - h4 * yh
			sb += yb * yb
			sh += yh * yh
		eb[k] = sb
		eh[k] = sh
		if (k & 4095) == 4095:
			_tick(1)
	var env := PackedFloat32Array()
	var bri := PackedFloat32Array()
	env.resize(nb)
	bri.resize(nb)
	var wb := 0.0
	var wh := 0.0
	for k in nb:
		wb += eb[k]
		wh += eh[k]
		if k >= V2_WIN:
			wb -= eb[k - V2_WIN]
			wh -= eh[k - V2_WIN]
		env[k] = sqrt(maxf(0.0, wb) / float(V2_WIN * V2_HOP))
		bri[k] = log((maxf(0.0, wh) + 1e-9) / (maxf(0.0, wb) + 1e-9))
	return {"env": env, "bri": bri, "sr": sr, "hop": V2_HOP}


func _gen_v2(S: Dictionary, di: int, dur: float, params: Dictionary) -> Array:
	var env: PackedFloat32Array = S["env"]
	var bri: PackedFloat32Array = S["bri"]
	var sr := float(S["sr"])
	var hop := int(S["hop"])
	var nb := env.size()
	if nb < 200:
		return []
	var P: Dictionary = C.V2D[di]
	var hs := float(hop) / sr
	var th := float(params.get("v2th", 50)) / 100.0
	var cd := maxf(float(P["cdMin"]), float(params.get("v2cd", 250)) / 1000.0 * float(P["cdK"]))
	var mult := 1.0 + th * 1.6 + float(P["thAdd"])
	var rise := PackedFloat32Array()
	rise.resize(nb)
	for k in range(V2_LAG, nb):
		rise[k] = env[k] - env[k - V2_LAG]
	var pre := PackedFloat64Array()
	pre.resize(nb + 1)
	for k in nb:
		pre[k + 1] = pre[k] + env[k]
	var mx := 0.0
	for k in nb:
		if env[k] > mx:
			mx = env[k]
	var floor_v := mx * 0.06
	var hw := roundi(1.0 / hs)
	var cand: Array = []
	for k in range(V2_LAG + 3, nb - V2_AHEAD - 2):
		var r := rise[k]
		if r <= 0.0:
			continue
		var pk := true
		for j in range(k - 3, k + 4):
			if rise[j] > r or (rise[j] == r and j < k):
				pk = false
				break
		if not pk:
			continue
		var a := maxi(0, k - hw)
		var z := mini(nb, k + hw + 1)
		var m := (pre[z] - pre[a]) / float(z - a)
		var top := 0.0
		var rm := 0.0
		for j in range(k, k + V2_AHEAD + 1):
			if env[j] > top:
				top = env[j]
			if rise[j] > rm:
				rm = rise[j]
		if top < m * mult or top < floor_v or r < rm * 0.25:
			continue
		cand.append({"t": float((k - V2_WIN + 1) * hop) / sr - 0.002, "s": r / (m + 1e-9), "b": bri[k + 2]})
	# cooldown
	var acc: Array = []
	for c in cand:
		var ct: float = c["t"]
		if ct < 1.2 or ct > dur - 0.85:
			continue
		if not acc.is_empty():
			var l: Dictionary = acc[acc.size() - 1]
			if ct - float(l["t"]) < cd:
				if ct - float(l["t"]) > 0.09 and float(c["s"]) > float(l["s"]) * 1.5 \
						and (acc.size() < 2 or ct - float(acc[acc.size() - 2]["t"]) >= cd):
					acc[acc.size() - 1] = c
				continue
		acc.append(c)
	if acc.is_empty():
		return []
	# lajur dari kecerahan relatif
	var ls: Array = P["lanes"]
	var nl := ls.size()
	var bs := PackedFloat32Array()
	var ss := PackedFloat32Array()
	for c in acc:
		bs.append(c["b"])
		ss.append(c["s"])
	bs.sort()
	ss.sort()
	var s_med := ss[ss.size() >> 1]
	var out: Array = []
	var pi := nl >> 1
	var pt := -9.0
	var dir := 1
	for c in acc:
		var ct: float = c["t"]
		var dt := ct - pt
		var rk := _rank(bs, float(c["b"]))
		var ti := mini(nl - 1, int(floor(rk * float(nl))))
		var mj := 1 if dt < 0.35 else 2
		var i := pi + maxi(-mj, mini(mj, ti - pi))
		if i == pi and dt < 0.6:
			dir = -dir
			i = pi + dir
			if i < 0 or i >= nl:
				i = pi - dir
		i = clampi(i, 0, nl - 1)
		out.append({"t": ct, "l": int(ls[i]), "dur": 0.0})
		if int(P["chord"]) == 1 and float(c["s"]) > s_med * 2.2 and dt > 0.4 and nl - 1 - i != i:
			out.append({"t": ct, "l": int(ls[nl - 1 - i]), "dur": 0.0})
		pi = i
		pt = ct
	return out


func _rank(sorted_arr: PackedFloat32Array, b: float) -> float:
	var lo := 0
	var hi := sorted_arr.size()
	while lo < hi:
		var m := (lo + hi) >> 1
		if sorted_arr[m] < b:
			lo = m + 1
		else:
			hi = m
	return float(lo) / float(sorted_arr.size() - 1) if sorted_arr.size() > 1 else 0.5


# ------------------------------------------------------------------ V3 (melodi / pitch)

func _run_v3(stream: AudioStream, id: String, dur: float, params: Dictionary) -> Array:
	var sens := float(params.get("v3th", 50))
	var cp := Store.cache_path(id, "v3")
	var V = Store.cache_read(cp)
	if V == null:
		var pcm := _get_pcm(stream)
		V = _scan_v3(pcm["x"], float(pcm["sr"]))
		if V.is_empty():
			return []
		Store.cache_write(cp, V)
	var tp := Store.cache_path(id, "v3t%d" % int(sens))
	var trk = Store.cache_read(tp)
	if trk == null:
		trk = _track_v3(V, sens / 100.0)
		Store.cache_write(tp, trk)
	_set_stage(6, 1)
	var out: Array = []
	for di in 3:
		out.append(_gen_v3(trk, di, dur, float(params.get("v3hl", 60)) / 100.0))
	return out


func _v3_tables(bw: float, lo: int, hi: int) -> Dictionary:
	var K := (V3_M1 - V3_M0) * V3_BPS + 1
	var off := PackedInt32Array()
	var qa := PackedInt32Array()
	var fa := PackedFloat32Array()
	var wa := PackedFloat32Array()
	off.resize(K + 1)
	for k in K:
		off[k] = qa.size()
		var f0 := 440.0 * pow(2.0, (float(V3_M0) + float(k) / float(V3_BPS) - 69.0) / 12.0)
		var h := 1
		while h <= V3_HM and float(h) * f0 <= V3_FMAX:
			var pos := float(h) * f0 / bw
			var q := int(floor(pos))
			if q >= lo and q <= hi:
				qa.append(q)
				fa.append(pos - float(q))
				wa.append(pow(0.86, float(h - 1)))
			h += 1
	off[K] = qa.size()
	return {"off": off, "qa": qa, "fa": fa, "wa": wa, "K": K}


func _job_v3(p0: int, p1: int, x: PackedFloat32Array, nF: int, tb: Dictionary, tt: Dictionary, lo: int, hi: int) -> Dictionary:
	var rev: PackedInt32Array = tb["rev"]
	var cs: PackedFloat32Array = tb["cs"]
	var sn: PackedFloat32Array = tb["sn"]
	var win: PackedFloat32Array = tb["win"]
	var off: PackedInt32Array = tt["off"]
	var qa: PackedInt32Array = tt["qa"]
	var fa: PackedFloat32Array = tt["fa"]
	var wa: PackedFloat32Array = tt["wa"]
	var K: int = tt["K"]
	var N := V3_N
	var half := N >> 1
	var re := PackedFloat32Array()
	var im := PackedFloat32Array()
	re.resize(N)
	im.resize(N)
	var mag := PackedFloat32Array()
	mag.resize(half)
	var csum := PackedFloat64Array()
	csum.resize(half + 1)
	var Y := PackedFloat32Array()
	Y.resize(half + 2)
	var nfr := (p1 - p0) * 2
	var S := PackedFloat32Array()
	S.resize(nfr * K)
	var rms := PackedFloat32Array()
	rms.resize(nfr)
	for p in range(p0, p1):
		var fr_a := p * 2
		var fr_b := fr_a + 1
		var oa := fr_a * V3_HOP
		var ob := fr_b * V3_HOP
		var hasb := fr_b < nF
		var ea := 0.0
		var eb := 0.0
		for i in N:
			var r := rev[i]
			var va := x[oa + i]
			ea += va * va
			re[r] = va * win[i]
			if hasb:
				var vb := x[ob + i]
				eb += vb * vb
				im[r] = vb * win[i]
			else:
				im[r] = 0.0
		_fft_br(re, im, N, cs, sn)
		var li := (p - p0) * 2
		rms[li] = sqrt(ea / float(N))
		rms[li + 1] = sqrt(eb / float(N))
		# frame A
		mag[0] = 0.0
		for k in range(1, half):
			var u := re[k] + re[N - k]
			var w := im[k] - im[N - k]
			mag[k] = 0.5 * sqrt(u * u + w * w)
		_v3_salience(mag, csum, Y, lo, hi, half, off, qa, fa, wa, K, S, li * K)
		# frame B
		for k in range(1, half):
			var u2 := im[k] + im[N - k]
			var w2 := re[k] - re[N - k]
			mag[k] = 0.5 * sqrt(u2 * u2 + w2 * w2)
		_v3_salience(mag, csum, Y, lo, hi, half, off, qa, fa, wa, K, S, (li + 1) * K)
		if (p & 15) == 15:
			_tick(16)
	return {"S": S, "rms": rms}


func _v3_salience(mag: PackedFloat32Array, csum: PackedFloat64Array, Y: PackedFloat32Array, lo: int, hi: int,
		half: int, off: PackedInt32Array, qa: PackedInt32Array, fa: PackedFloat32Array, wa: PackedFloat32Array,
		K: int, S: PackedFloat32Array, so: int) -> void:
	csum[0] = 0.0
	for i in half:
		csum[i + 1] = csum[i] + mag[i]
	# whitening spektral: bagi dengan rata-rata lokal (lebar ~10% frekuensi)
	for i in range(lo - 1, hi + 2):
		var w := maxi(5, roundi(float(i) * 0.1))
		var u := maxi(0, i - w)
		var v := mini(half, i + w + 1)
		var m := (csum[v] - csum[u]) / float(v - u)
		Y[i] = sqrt(maxf(0.0, mag[i] / (m + 1e-9) - 1.0))
	for k in K:
		var s := 0.0
		for h in range(off[k], off[k + 1]):
			var q := qa[h]
			s += wa[h] * (Y[q] * (1.0 - fa[h]) + Y[q + 1] * fa[h])
		S[so + k] = s


func _scan_v3(x2: PackedFloat32Array, sr2: float) -> Dictionary:
	# turunkan lagi 2x -> ~5.5 kHz
	var nd := x2.size() / 2
	var x := PackedFloat32Array()
	x.resize(nd)
	for j in nd:
		x[j] = (x2[2 * j] + x2[2 * j + 1]) * 0.5
	var sd := sr2 / 2.0
	var N := V3_N
	var nF := (nd - N) / V3_HOP + 1
	if nF < 20:
		return {}
	var bw := sd / float(N)
	var lo := maxi(2, int(floor(80.0 / bw)))
	var hi := mini((N >> 1) - 2, int(floor(V3_FMAX / bw)))
	var tb := _fft_tables(N)
	var tt := _v3_tables(bw, lo, hi)
	var K: int = tt["K"]
	var pairs := (nF + 1) / 2
	_set_stage(4, pairs)
	var job := _job_v3.bind(x, nF, tb, tt, lo, hi)
	var parts := _par(job, pairs)
	var S := PackedFloat32Array()
	var rms := PackedFloat32Array()
	for part in parts:
		S.append_array(part["S"])
		rms.append_array(part["rms"])
	S.resize(nF * K)
	rms.resize(nF)
	return {"S": S, "rms": rms, "nF": nF, "K": K, "hopT": float(V3_HOP) / sd, "t0": float(N) / 2.0 / sd}


func _close_seg(seg: Array, cur_a: int, e: int, ms: PackedFloat32Array, amp: PackedFloat32Array) -> void:
	if cur_a < 0 or e - cur_a < 2:
		return
	var w := PackedFloat32Array()
	var am2 := 0.0
	for q in range(cur_a, e):
		if not is_nan(ms[q]):
			w.append(ms[q])
			am2 += amp[q]
	if w.is_empty():
		return
	w.sort()
	seg.append({"a": cur_a, "b": e, "p": roundi(w[w.size() >> 1]), "s": am2 / float(w.size())})


## Viterbi (nada + status suara/hening) -> segmentasi not.
func _track_v3(v: Dictionary, sens: float) -> Dictionary:
	var S: PackedFloat32Array = v["S"]
	var rms: PackedFloat32Array = v["rms"]
	var nF := int(v["nF"])
	var K := int(v["K"])
	var BPS := V3_BPS
	var M0 := V3_M0
	var th := 0.55 - 0.4 * sens
	_set_stage(5, nF * 3)
	# median-3 antar frame (buang lonjakan 1 frame, mis. drum)
	var Sm := PackedFloat32Array()
	Sm.resize(nF * K)
	for t in nF:
		var ta := maxi(0, t - 1)
		var tc := mini(nF - 1, t + 1)
		var ba := ta * K
		var bb := t * K
		var bc := tc * K
		for k in K:
			var p := S[ba + k]
			var q := S[bb + k]
			var r := S[bc + k]
			Sm[bb + k] = maxf(minf(p, q), minf(maxf(p, q), r))
	_tick(nF)
	var mx := PackedFloat32Array()
	var mean := PackedFloat32Array()
	var am := PackedInt32Array()
	mx.resize(nF)
	mean.resize(nF)
	am.resize(nF)
	for t in nF:
		var s := 0.0
		var m := -1.0
		var mi := 0
		var bb := t * K
		for k in K:
			var q := Sm[bb + k]
			s += q
			if q > m:
				m = q
				mi = k
		mean[t] = s / float(K)
		mx[t] = m - s / float(K)
		am[t] = mi
	_tick(nF)
	var rs := rms.duplicate()
	rs.sort()
	var gate := rs[int(floor(float(nF) * 0.95))] * 0.03
	var okv := PackedFloat32Array()
	for t in nF:
		if rms[t] > gate:
			okv.append(mx[t])
	okv.sort()
	var ref := 1.0
	if okv.size() > 0:
		ref = maxf(1e-6, okv[int(floor(float(okv.size()) * 0.9))])
	var hist := PackedFloat32Array()
	hist.resize(K)
	for t in nF:
		if rms[t] > gate and mx[t] > 0.5 * ref:
			hist[am[t]] += 1.0
	var tot := 0.0
	for k in K:
		tot += hist[k]
	var cum := 0.0
	var pc := float(M0) + float(K - 1) / float(BPS) / 2.0
	for k in K:
		cum += hist[k]
		if cum >= tot / 2.0:
			pc = float(M0) + float(k) / float(BPS)
			break
	var pri := PackedFloat32Array()
	pri.resize(K)
	for k in K:
		var z := (float(M0) + float(k) / float(BPS) - pc) / 9.0
		pri[k] = exp(-0.5 * z * z)
	var lam := 0.06 / float(BPS)
	var cmax := 5.0 * float(BPS)
	var mu := 0.4
	var U := K
	var K1 := K + 1
	var bp := PackedInt32Array()
	bp.resize(nF * K1)
	var d := PackedFloat32Array()
	var nd := PackedFloat32Array()
	var fw := PackedFloat32Array()
	var fi := PackedInt32Array()
	d.resize(K1)
	nd.resize(K1)
	fw.resize(K)
	fi.resize(K)
	for t in nF:
		var g := rms[t] > gate
		var gm := -1e9
		var gi := 0
		for k in K:
			if d[k] > gm:
				gm = d[k]
				gi = k
		var run := -1e9
		var ri := 0
		for k in K:
			if d[k] >= run - lam:
				run = d[k]
				ri = k
			else:
				run -= lam
			fw[k] = run
			fi[k] = ri
		run = -1e9
		for k in range(K - 1, -1, -1):
			if d[k] >= run - lam:
				run = d[k]
				ri = k
			else:
				run -= lam
			if run > fw[k]:
				fw[k] = run
				fi[k] = ri
		var cap := gm - lam * cmax
		var from_u := d[U] - mu
		var bb := t * K
		var bo := t * K1
		var mt := mean[t]
		for k in K:
			var best := fw[k]
			var src := fi[k]
			if cap > best:
				best = cap
				src = gi
			if from_u > best:
				best = from_u
				src = U
			var o := -1.0
			if g:
				o = minf(1.5, maxf(0.0, Sm[bb + k] - mt) / ref) * (0.7 + 0.3 * pri[k])
			nd[k] = best + o
			bp[bo + k] = src
		var from_p := gm - mu
		nd[U] = maxf(d[U], from_p) + (th if g else 0.6)
		bp[bo + U] = U if d[U] >= from_p else gi
		var mm := -1e9
		for k in K1:
			if nd[k] > mm:
				mm = nd[k]
		for k in K1:
			nd[k] -= mm
		var tmp := d
		d = nd
		nd = tmp
		if (t & 255) == 255:
			_tick(256)
	var st := 0
	var bv := -1e9
	for k in K1:
		if d[k] > bv:
			bv = d[k]
			st = k
	var path := PackedInt32Array()
	path.resize(nF)
	for t in range(nF - 1, -1, -1):
		path[t] = st
		st = bp[t * K1 + st]
	var m_arr := PackedFloat32Array()
	m_arr.resize(nF)
	m_arr.fill(NAN)
	var amp := PackedFloat32Array()
	amp.resize(nF)
	for t in nF:
		var k := path[t]
		if k == U:
			continue
		var dl := 0.0
		if k > 0 and k < K - 1:
			var pp := Sm[t * K + k - 1]
			var qq := Sm[t * K + k]
			var rr := Sm[t * K + k + 1]
			var dn := pp - 2.0 * qq + rr
			if dn < 0.0:
				dl = clampf(0.5 * (pp - rr) / dn, -0.5, 0.5)
		m_arr[t] = float(M0) + (float(k) + dl) / float(BPS)
		amp[t] = maxf(0.0, Sm[t * K + k] - mean[t]) / ref
	# tuning: rata-rata sirkular bagian pecahan semiton
	var zc := 0.0
	var zs := 0.0
	var nn := 0
	for t in nF:
		if not is_nan(m_arr[t]):
			zc += cos(TAU * m_arr[t])
			zs += sin(TAU * m_arr[t])
			nn += 1
	var R := sqrt(zc * zc + zs * zs) / float(nn) if nn > 0 else 0.0
	var tune := atan2(zs, zc) / TAU if R > 0.12 else 0.0
	for t in nF:
		if not is_nan(m_arr[t]):
			m_arr[t] -= tune
	# jembatani celah hening pendek
	var t2 := 1
	while t2 < nF - 1:
		if is_nan(m_arr[t2]):
			var e := t2
			while e < nF and is_nan(m_arr[e]):
				e += 1
			if e < nF and e - t2 <= 4 and absf(m_arr[t2 - 1] - m_arr[e]) < 1.0:
				for q in range(t2, e):
					m_arr[q] = m_arr[t2 - 1]
			t2 = e
		t2 += 1
	# median-5
	var ms := m_arr.duplicate()
	for t in range(2, nF - 2):
		if not is_nan(m_arr[t]):
			var w := PackedFloat32Array()
			for q in range(t - 2, t + 3):
				if not is_nan(m_arr[q]):
					w.append(m_arr[q])
			w.sort()
			ms[t] = w[w.size() >> 1]
	# segmentasi histeresis
	var seg: Array = []
	var cur_a := -1
	var cur_p := 0
	var cand_r := -99999
	var cand_n := 0
	var cand_t0 := 0
	for t in nF:
		var v2 := ms[t]
		if is_nan(v2):
			_close_seg(seg, cur_a, t, ms, amp)
			cur_a = -1
			cand_n = 0
			continue
		if cur_a < 0:
			cur_a = t
			cur_p = roundi(v2)
			cand_n = 0
			continue
		if absf(v2 - float(cur_p)) <= 0.7:
			cand_n = 0
			continue
		var rr2 := roundi(v2)
		if cand_n > 0 and cand_r == rr2:
			cand_n += 1
		else:
			cand_r = rr2
			cand_n = 1
			cand_t0 = t
		if cand_n >= 3:
			_close_seg(seg, cur_a, cand_t0, ms, amp)
			cur_a = cand_t0
			cur_p = cand_r
			cand_n = 0
	_close_seg(seg, cur_a, nF, ms, amp)
	return {"seg": seg, "tune": tune, "R": R, "hopT": float(v["hopT"]), "t0": float(v["t0"])}


func _gen_v3(trk: Dictionary, di: int, dur: float, hl: float) -> Array:
	var P: Dictionary = C.V3D[di]
	var hm := float(P["hold"]) * (hl / 0.6)
	var ls: Array = P["lanes"]
	var nl := ls.size()
	var seg: Array = trk["seg"]
	var hop_t := float(trk["hopT"])
	var t0 := float(trk["t0"])
	var cmin := float(P["min"])
	var gap := float(P["gap"])
	var trim := float(P["trim"])
	var c: Array = []
	for s in seg:
		var d := float(int(s["b"]) - int(s["a"])) * hop_t
		var t := t0 + float(s["a"]) * hop_t
		if d >= cmin and t >= 1.2 and t < dur - 0.85:
			c.append({"t": t, "d": d, "p": int(s["p"]), "imp": pow(d, 0.6) * (0.3 + float(s["s"]))})
	c.sort_custom(_cmp_imp)
	var ac: Array = []
	for n in c:
		var ok := true
		for a in ac:
			if absf(float(a["t"]) - float(n["t"])) < gap:
				ok = false
				break
		if ok:
			ac.append(n)
	ac.sort_custom(_cmp_t)
	var cnt := {}
	var tot := 0.0
	for n in ac:
		var w := sqrt(float(n["d"]))
		cnt[n["p"]] = float(cnt.get(n["p"], 0.0)) + w
		tot += w
	var ps: Array = cnt.keys()
	ps.sort()
	var lane := {}
	var cum := 0.0
	for p in ps:
		var w2 := float(cnt[p])
		lane[p] = int(ls[mini(nl - 1, int(floor((cum + w2 / 2.0) / tot * float(nl))))])
		cum += w2
	var out: Array = []
	for i in ac.size():
		var n: Dictionary = ac[i]
		var nx := float(ac[i + 1]["t"]) if i + 1 < ac.size() else dur
		var dd := minf(minf(float(n["d"]) - trim, nx - float(n["t"]) - 0.12), 8.0)
		dd = dd if (dd >= hm and float(n["t"]) + dd < dur - 0.2) else 0.0
		out.append({"t": float(n["t"]), "l": int(lane[n["p"]]), "dur": dd})
	return out


static func _cmp_imp(a: Dictionary, b: Dictionary) -> bool:
	return a["imp"] > b["imp"]


static func _cmp_t(a: Dictionary, b: Dictionary) -> bool:
	return a["t"] < b["t"]
