extends Control
## Roda warna HSL bergaya versi web: cincin (sudut = hue, jari-jari = lightness), label derajat,
## cakram tengah menampilkan hue + S/L. Cincin digambar shader; marker digambar di atasnya.

const FX = preload("res://scripts/fx.gd")
signal picked(h: float, l: float)

const SHADER := """
shader_type canvas_item;
uniform float sat = 1.0;
uniform float ri = 0.224;
uniform float ro = 0.372;
uniform float lmin = 0.30;
uniform float lmax = 0.90;
vec3 hsl2rgb(float h, float s, float l) {
	float q = l < 0.5 ? l * (1.0 + s) : l + s - l * s;
	float p = 2.0 * l - q;
	vec3 t = vec3(h + 1.0 / 3.0, h, h - 1.0 / 3.0);
	vec3 c = vec3(0.0);
	for (int i = 0; i < 3; i++) {
		float tt = fract(t[i]);
		float v = p;
		if (tt < 1.0 / 6.0) v = p + (q - p) * 6.0 * tt;
		else if (tt < 0.5) v = q;
		else if (tt < 2.0 / 3.0) v = p + (q - p) * (2.0 / 3.0 - tt) * 6.0;
		c[i] = v;
	}
	return c;
}
void fragment() {
	vec4 base = COLOR;
	vec2 d = UV - vec2(0.5);
	float dist = length(d);
	float ang = fract(atan(d.x, -d.y) / 6.28318530718);
	float r = clamp((ro - dist) / (ro - ri), 0.0, 1.0);
	float l = mix(lmin, lmax, r);
	float aa = 0.004;
	float a = smoothstep(ri - aa, ri + aa, dist) * (1.0 - smoothstep(ro - aa, ro + aa, dist));
	COLOR = vec4(hsl2rgb(ang, sat, l) * base.rgb, a * base.a);
}
"""

const RI := 0.224
const RO := 0.372
const LMIN := 30.0
const LMAX := 90.0

var hue := 0.0
var light := 60.0
var sat_pct := 100.0
var marker_color := Color.WHITE
var _ring: ColorRect
var _mat: ShaderMaterial
var _drag := false


func _init() -> void:
	custom_minimum_size = Vector2(200, 200)
	mouse_filter = Control.MOUSE_FILTER_STOP
	_ring = ColorRect.new()
	_ring.color = Color.WHITE
	_ring.set_anchors_preset(Control.PRESET_FULL_RECT)
	_ring.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_ring.show_behind_parent = true
	var sh := Shader.new()
	sh.code = SHADER
	_mat = ShaderMaterial.new()
	_mat.shader = sh
	_ring.material = _mat
	add_child(_ring)


func set_state(h: float, l: float, sat_percent: float, col: Color) -> void:
	hue = h
	light = l
	sat_pct = sat_percent
	marker_color = col
	_mat.set_shader_parameter("sat", sat_percent / 100.0)
	queue_redraw()


func _pick(pos: Vector2) -> void:
	var s := minf(size.x, size.y)
	var dx := (pos.x - size.x * 0.5) / s
	var dy := (pos.y - size.y * 0.5) / s
	var dist := sqrt(dx * dx + dy * dy)
	var ang := fposmod(rad_to_deg(atan2(dx, -dy)), 360.0)
	var r := clampf((RO - dist) / (RO - RI), 0.0, 1.0)
	picked.emit(ang, LMIN + r * (LMAX - LMIN))


func _gui_input(e: InputEvent) -> void:
	if e is InputEventMouseButton and e.button_index == MOUSE_BUTTON_LEFT:
		if e.pressed:
			var s := minf(size.x, size.y)
			var dx: float = (e.position.x - size.x * 0.5) / s
			var dy: float = (e.position.y - size.y * 0.5) / s
			var dist := sqrt(dx * dx + dy * dy)
			if dist >= RI - 0.05 and dist <= RO + 0.12:
				_drag = true
				_pick(e.position)
				accept_event()
		elif _drag:
			_drag = false
			accept_event()
	elif e is InputEventMouseMotion and _drag:
		_pick(e.position)
		accept_event()


func _draw() -> void:
	var s := minf(size.x, size.y)
	var c := size * 0.5
	var font := FX.font("medium")
	var fs := maxi(7, int(s * 0.04))
	for k in 12:
		var deg := k * 30
		var a := deg_to_rad(float(deg))
		var p := c + Vector2(sin(a), -cos(a)) * s * 0.455
		var txt := "%d°" % deg
		var w := font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		draw_string(font, p + Vector2(-w / 2.0, fs * 0.36), txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, 0.55))
	# cakram tengah
	var r0 := s * 0.2
	draw_circle(c, r0 + s * 0.035, Color(marker_color.r, marker_color.g, marker_color.b, 0.18))
	draw_circle(c, r0 + 2.0, Color(0.08, 0.06, 0.2, 1.0))
	draw_circle(c, r0, marker_color)
	var dark := marker_color.get_luminance() > 0.6
	var tc := Color(0.1, 0.07, 0.2) if dark else Color.WHITE
	var bold := FX.font("bold")
	var f1 := maxi(9, int(s * 0.075))
	var t1 := "%d°" % int(round(hue))
	var w1 := bold.get_string_size(t1, HORIZONTAL_ALIGNMENT_LEFT, -1, f1).x
	draw_string(bold, c + Vector2(-w1 / 2.0, -s * 0.005), t1, HORIZONTAL_ALIGNMENT_LEFT, -1, f1, tc)
	var f2 := maxi(6, int(s * 0.036))
	var t2 := "S %d · L %d" % [int(round(sat_pct)), int(round(light))]
	var w2 := font.get_string_size(t2, HORIZONTAL_ALIGNMENT_LEFT, -1, f2).x
	draw_string(font, c + Vector2(-w2 / 2.0, s * 0.055), t2, HORIZONTAL_ALIGNMENT_LEFT, -1, f2, Color(tc.r, tc.g, tc.b, 0.85))
	# marker di cincin
	var rr := clampf((light - LMIN) / (LMAX - LMIN), 0.0, 1.0)
	var dist := RO - rr * (RO - RI)
	var t := deg_to_rad(hue)
	var mp := c + Vector2(sin(t), -cos(t)) * dist * s
	var mr := s * 0.032
	draw_circle(mp, mr + 2.5, Color(0, 0, 0, 0.45))
	draw_circle(mp, mr + 1.5, Color.WHITE)
	draw_circle(mp, mr - 1.0, marker_color)
