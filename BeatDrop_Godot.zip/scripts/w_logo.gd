extends Control
## Logo "BeatDrop": Beat putih + Drop gradien pelangi beranimasi, dengan bayangan bertumpuk (3D).

const FX = preload("res://scripts/fx.gd")

const SHADER := """
shader_type canvas_item;
const vec3 P[6] = vec3[6](vec3(1.0, 0.239, 0.506), vec3(1.0, 0.624, 0.11), vec3(0.18, 0.9, 0.65), vec3(0.227, 0.627, 1.0), vec3(0.702, 0.42, 1.0), vec3(1.0, 0.239, 0.506));
void fragment() {
	vec4 base = COLOR;
	float t = fract(UV.x * 0.55 + TIME * 0.12) * 5.0;
	int i = int(floor(t));
	float f = fract(t);
	vec3 c = mix(P[i], P[i + 1], f);
	COLOR = vec4(c * base.rgb, base.a);
}
"""

var _front: HBoxContainer
var _fsize := 36


func setup(font_size: int) -> void:
	_fsize = font_size
	for ch in get_children():
		ch.queue_free()
	var layers := [[Color("#1b1350"), 7.0], [Color("#2a1f6b"), 3.5], [Color.WHITE, 0.0]]
	for lay in layers:
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 0)
		h.mouse_filter = Control.MOUSE_FILTER_IGNORE
		var a := _lbl("Beat", lay[0] if lay[1] > 0.0 else Color("#f5f2ff"))
		var b := _lbl("Drop", lay[0] if lay[1] > 0.0 else Color.WHITE)
		if lay[1] <= 0.0:
			var sh := Shader.new()
			sh.code = SHADER
			var m := ShaderMaterial.new()
			m.shader = sh
			b.material = m
		h.add_child(a)
		h.add_child(b)
		h.position = Vector2(0.0, float(lay[1]))
		add_child(h)
		_front = h
	custom_minimum_size = _front.get_combined_minimum_size() + Vector2(0.0, 8.0)


func _lbl(t: String, c: Color) -> Label:
	var l := Label.new()
	l.text = t
	l.add_theme_font_override("font", FX.font("bold"))
	l.add_theme_font_size_override("font_size", _fsize)
	l.add_theme_color_override("font_color", c)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l
