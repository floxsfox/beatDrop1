extends "res://scripts/s_base.gd"
## Menu jeda (tombol ll): Resume / Retry / Menu.


func _ready() -> void:
	set_bg_alpha(0.7)
	var col := UI.vbox(0)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	mc.add_child(col)
	var cc := CenterContainer.new()
	cc.mouse_filter = Control.MOUSE_FILTER_PASS
	col.add_child(cc)
	var card := UI.card(FX.s_panel(), 28, 20, 28, 22)
	cc.add_child(card)
	var v := UI.vbox(10)
	card.body.add_child(v)
	v.add_child(UI.label("Paused", 26, FX.TX, "bold", HORIZONTAL_ALIGNMENT_CENTER))
	v.add_child(UI.spacer(0, 4))
	var st := FX.s_primary()
	st["shine"] = true
	var rs := UI.btn("RESUME", 16, st, Vector2(230, 46), Color.WHITE, 2)
	rs.pressed.connect(func(): nav.emit("resume", {}))
	v.add_child(rs)
	var rt := UI.btn("Retry", 14, FX.s_ghost(), Vector2(230, 40))
	rt.pressed.connect(func(): nav.emit("retry", {}))
	v.add_child(rt)
	var mn := UI.btn("Quit to menu", 14, FX.s_ghost(), Vector2(230, 40))
	mn.pressed.connect(func(): nav.emit("menu", {}))
	v.add_child(mn)


func on_enter(_args: Dictionary = {}) -> void:
	fade_in(0.15)


func on_back() -> void:
	nav.emit("resume", {})
