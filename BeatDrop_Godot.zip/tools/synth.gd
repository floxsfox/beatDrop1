extends RefCounted
## Lagu sintetis 120 BPM (30 dtk) untuk uji CI.


static func make() -> AudioStreamWAV:
	var sr := 22050
	var n := sr * 30
	var bytes := PackedByteArray()
	bytes.resize(n * 2)
	var beat := 0.5
	var freqs := [440.0, 523.25, 659.25, 783.99]
	for i in n:
		var t := float(i) / float(sr)
		var ph := fmod(t, beat)
		var v := 0.8 * sin(TAU * (50.0 + 100.0 * exp(-ph * 30.0)) * ph) * exp(-ph * 14.0)
		var f: float = freqs[int(t / beat) % 4]
		v += 0.25 * sin(TAU * f * t) * exp(-ph * 4.0)
		bytes.encode_s16(i * 2, clampi(int(v * 20000.0), -32768, 32767))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = sr
	w.stereo = false
	w.data = bytes
	return w
