extends Node
## Uji mandiri untuk CI: membuat lagu sintetis 120 BPM, menjalankan Analyzer V1/V2/V3 di Godot sungguhan,
## lalu mencetak hasilnya. Tidak ikut masuk APK (dikecualikan di export_presets.cfg).

const Analyzer = preload("res://scripts/analyzer.gd")


func _ready() -> void:
	call_deferred("_run")


func _synth() -> AudioStreamWAV:
	var sr := 22050
	var n := sr * 30
	var bytes := PackedByteArray()
	bytes.resize(n * 2)
	var beat := 0.5
	var freqs := [440.0, 523.25, 659.25, 783.99]
	for i in n:
		var t := float(i) / float(sr)
		var ph := fmod(t, beat)
		var v := 0.8 * sin(TAU * (50.0 + 100.0 * exp(-ph * 30.0)) * ph) * exp(-ph * 14.0)
		var f: float = freqs[int(t / beat) % 4]
		v += 0.25 * sin(TAU * f * t) * exp(-ph * 4.0)
		bytes.encode_s16(i * 2, clampi(int(v * 20000.0), -32768, 32767))
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = sr
	w.stereo = false
	w.data = bytes
	return w


func _run() -> void:
	var stream := _synth()
	print("SELFTEST length=", stream.get_length(), " mix_rate=", AudioServer.get_mix_rate())
	var ok := true
	for gen in [1, 2, 3]:
		var an := Analyzer.new()
		var t0 := Time.get_ticks_msec()
		an.start(stream, "selftest", gen, Store.SET.duplicate())
		while not an.finished and Time.get_ticks_msec() - t0 < 240000:
			await get_tree().process_frame
		if not an.finished:
			print("SELFTEST FAIL gen=", gen, " timeout at stage ", an.stage)
			ok = false
			break
		an.join()
		var counts: Array = []
		for a in an.result:
			counts.append(a.size())
		print("SELFTEST gen=", gen, " used=", an.used_gen, " notes(easy,normal,hard)=", counts, " ms=", Time.get_ticks_msec() - t0)
		if gen == 1 and int(counts[1]) < 10:
			print("SELFTEST FAIL V1 produced too few notes")
			ok = false
		if int(an.used_gen) != gen:
			print("SELFTEST WARN generator ", gen, " fell back to V", an.used_gen)
	Store.cache_clear()
	print("SELFTEST ", "OK" if ok else "FAIL")
	get_tree().quit(0 if ok else 1)
