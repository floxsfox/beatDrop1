extends Node
## Uji UI di CI: menjalankan main.tscn, mengunjungi semua layar, memulai gameplay singkat (tekan lajur,
## jeda, lanjut, selesai) sehingga error skrip saat runtime terlihat sebelum APK dibuat.

const Analyzer = preload("res://scripts/analyzer.gd")
const Synth = preload("res://tools/synth.gd")

var _m


func _ready() -> void:
	call_deferred("_run")


func _wait(n: int) -> void:
	for i in n:
		await get_tree().process_frame


func _run() -> void:
	var packed: PackedScene = load("res://main.tscn")
	_m = packed.instantiate()
	get_tree().root.add_child(_m)
	await _wait(10)
	print("UITEST booted")
	_m.intro._finish()
	await _wait(30)
	var stream: AudioStreamWAV = Synth.make()
	Store.library.append({"id": "uitest", "name": "UI Test Song", "ext": "mp3", "dur": 30.0, "bytes": 1234567, "thumb": false, "added": 0})
	Store.sg["uitest"] = {"A+": 2, "S": 1}
	Store.best["uitest:1"] = 54271
	for scr in ["lib", "ach", "settings", "menu"]:
		_m._goto(scr)
		await _wait(20)
		print("UITEST screen ", scr)
	var st = _m.screens["settings"]
	_m._goto("settings")
	for i in 5:
		st._show_tab(i)
		await _wait(6)
	print("UITEST settings tabs")
	var an := Analyzer.new()
	an.start(stream, "uitest", 1, Store.SET.duplicate())
	while not an.finished:
		await get_tree().process_frame
	an.join()
	_m.cur_song_id = "uitest"
	_m.cur_song_name = "UI Test Song"
	_m.cur_stream = stream
	_m.cur_notes = an.result
	_m.cur_gen_used = 1
	var counts: Array = []
	for a in an.result:
		var holds := 0
		for n in a:
			if float(n["dur"]) > 0.0:
				holds += 1
		counts.append({"n": a.size(), "h": holds})
	_m._goto("detail", {"id": "uitest", "counts": counts, "gen": 1, "diff": 1})
	await _wait(20)
	_m.screens["detail"]._pick_diff(2)
	await _wait(5)
	print("UITEST detail")
	_m._launch_game(1)
	await _wait(5)
	var g = _m.game
	g.t_go_usec = Time.get_ticks_usec() - 1000
	await _wait(60)
	for l in 5:
		g.press(l)
		await _wait(2)
		g.release(l)
	await _wait(60)
	g.pause_game()
	await _wait(20)
	print("UITEST paused state=", g.state, " screen=", _m.cur_screen)
	_m._on_nav("resume", {})
	await _wait(150)
	print("UITEST resumed state=", g.state)
	g._finish(false)
	await _wait(40)
	print("UITEST result screen=", _m.cur_screen)
	_m._goto("menu")
	await _wait(10)
	print("UITEST DONE")
	get_tree().quit(0)
